# 素材・ライセンス情報

## 同梱素材

このプロジェクトの `assets/` にある画像と音声は、このNovelScriptテストパック用に独自制作・プログラム生成したオリジナル素材です。

- `bg_*.svg`：このテストパック向けに独自作成したベクター背景（雨の駅、喫茶店、川沿い、朝の社）
- `mio_*.svg`：このテストパック向けに独自作成したベクター立ち絵と表情差分
- `bgm_*.wav`：シンセサイザーで新規合成したループBGM
- `se_*.wav` / `ambience_rain.wav`：コードから合成した効果音・環境音

第三者の画像・音源をコピーしていません。外部素材のライセンス条項を同梱素材に誤適用しないよう、同梱物は「独自制作」として管理しています。配布・改変時はこのクレジットファイルを残してください。

## 確認済みの外部CC0素材（今回のZIPには未同梱）

外部配布元のページ上でCC0またはCreative Commons Zeroと明記されている素材です。今回の実行環境では元ファイル本体への直接ダウンロードができなかったため、出典とライセンス確認先のみを案内しています。

- **Breezy — Visual Novel Sprites!**（4キャラクター、複数表情、PNG/PSD） — CC0、商用利用・改変・再配布可、クレジット不要と配布ページに記載。<https://breezy-the-cat.itch.io/visual-novel-sprites>
- **FALLiNG_AiR — Visual Novel Character Sprite**（ビジュアルノベル用立ち絵） — OpenGameArtの配布ページでCC0と記載。<https://opengameart.org/content/visual-novel-character-sprite>
- **TinyWorlds — Forest Ambience**（ループ環境音） — OpenGameArtの配布ページでCC0と記載。<https://opengameart.org/content/forest-ambience>
- **Kenney — RPG Audio**（RPG向け効果音50点） — Kenney公式アセットページでCC0と記載。<https://kenney.nl/assets/rpg-audio>
- **Kenney — Nature Kit**（自然環境の3D素材） — Kenney公式アセットページでCC0と記載。<https://kenney.nl/assets/nature-kit>
- **OpenGameArt — 2D City backgrounds**（PNG背景3点） — 配布ページでCC0と記載。<https://opengameart.org/content/2d-city-backgrounds>

Kenneyのライセンス説明：<https://kenney.nl/support>（同サイトのアセットページで公開されるゲーム素材はCC0、商用利用可、クレジット不要と説明）。

## 利用時の注意

「ロイヤリティフリー」と「CC0」は同じ意味ではありません。外部素材を追加する際は、素材ごとのページ・同梱LICENSE・権利者の条件を確認し、URL・作者・ライセンス・取得日を記録してください。人物・商標・第三者のロゴ等には、著作権とは別の権利が残る場合があります。
