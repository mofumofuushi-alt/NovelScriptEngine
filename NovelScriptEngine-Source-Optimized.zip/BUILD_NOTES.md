# v1.8 Build Notes

- Native Tkinter Windows desktop application; no browser, WebView or network runtime.
- Single-file PyInstaller build bundles Python and Tcl/Tk; end-user Python installation is not required.
- Runtime user data remains outside the EXE in `%APPDATA%\\NovelScriptEngine`.
- v1.4 adds right-click system menu, 10 per-scenario save slots, full interpreter/UI-state restore, wait timer continuation and a scrollable dialogue/choice backlog.
- v1.5 captures the visible game canvas as a PNG per save slot and previews it in the save/load window. Images are capped at 480×270 and stored separately from JSON save records.
- Pillow is included as a build dependency and bundled into the one-file EXE; runtime capture is offline. Legacy v1.4 JSON saves remain loadable even without thumbnails.
- Save files use a SHA-256-derived scenario fingerprint; saves for distinct exact script sources are isolated.
- Save writes use a temporary file followed by atomic replace.
- Existing `.nse` command syntax and `select` branching have not changed.
- GUI smoke test covers right-click menu, save/load of pending-choice state, reconstruction of a fresh player from a save, slot deletion and backlog UI, plus screenshot capture, PNG validation, slot image deletion and preview UI.

- v1.7 adds independent transparent character layers, drag movement, Z-order and visibility management. Mouth layers switch between closed/open PNGs while dialogue is active; optional WAV voice tracks drive mouth animation for the WAV duration.
- v1.8 removes in-game dragging for both character sprites and overlay layers. Legacy `chara` X/Y values and v1.6 save coordinates are migrated to the nearest fixed `left` / `center` / `right` anchor; layer composition coordinates remain script-defined for mouth/eye alignment.
- Voice and layer state are persisted in the existing version-1 save container without changing the outer save schema; old saves default to an empty layer set.
