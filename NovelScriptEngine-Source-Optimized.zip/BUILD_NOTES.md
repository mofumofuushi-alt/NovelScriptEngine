# NovelScript Engine v1.3 Windows EXEビルドについて

- 対象: Windows 10/11 x64
- GUI: Tkinter（Python標準ライブラリ）
- EXE化: PyInstaller one-file / windowed
- 内包するデータ: assets, assets_png, examples
- アプリ起動時: Python、pip、WebView、Webサーバー、ネット接続は不要
- 選択肢: ゲームステージ内のCanvasにカード状で描画し、クリック／数字キー1〜9で選択
- CI検証: ユニットテスト12件とTkinter GUIスモークテストを実行
- ユーザー設定: `%APPDATA%\NovelScriptEngine\settings.json` に書き込み（実行ファイルのあるフォルダは変更しない）
- ビルド時: Windows上のPython 3.12とPyInstallerが必要。PyInstallerの取得に初回のみネット接続が必要

## ローカルビルド
`build_windows.bat` を実行すると `.build-venv` を作り、PyInstallerを導入して `release\NovelScriptEngine.exe` を生成します。

## GitHub Actions
`.github/workflows/build-windows.yml` は `windows-2022` runner上でx64 EXEを作り、Actions artifactとして30日間保存します。

## この成果物でEXEを同梱していない理由
ビルド作業環境はLinux x86_64で、Windows Python／Windows runner／Wine／MinGWがありません。PyInstallerは対象OS上で実行して対象OS用バイナリを作る方式であり、この環境からWindows EXEを直接生成したと偽ってはいけないため、再現可能なWindowsビルド手順を提供しています。

## v1.3 click advance

- Click anywhere on the in-game canvas to advance text.
- During typewriter animation, click once to complete the line and click again to continue.
- Choice and wait states ignore background clicks; choice card clicks stop propagation to prevent double advance.
- GUI smoke test covers click-to-advance, typewriter completion and choice event isolation.
