# v1.5 Build Notes

- Native Tkinter Windows desktop application; no browser, WebView or network runtime.
- Single-file PyInstaller build bundles Python and Tcl/Tk; end-user Python installation is not required.
- Runtime user data remains outside the EXE in `%APPDATA%\\NovelScriptEngine`.
- v1.4 adds right-click system menu, 10 per-scenario save slots, full interpreter/UI-state restore, wait timer continuation and a scrollable dialogue/choice backlog.
- v1.5 captures the visible game canvas as a PNG per save slot and previews it in the save/load window. Images are capped at 480×270 and stored separately from JSON save records.
- Pillow is included as a build dependency and bundled into the one-file EXE; runtime capture is offline. Legacy v1.4 JSON saves remain loadable even without thumbnails.
- Save files use a SHA-256-derived scenario fingerprint; saves for distinct exact script sources are isolated.
- Save writes use a temporary file followed by atomic replace.
- Existing `.nse` command syntax and `select` branching have not changed.
- GUI smoke test covers right-click menu, save/load of pending-choice state, reconstruction of a fresh player from a save, slot deletion and backlog UI, plus screenshot capture, PNG validation, slot image deletion and preview UI.
