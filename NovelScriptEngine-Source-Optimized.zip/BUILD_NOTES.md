# v1.4 Build Notes

- Native Tkinter Windows desktop application; no browser, WebView or network runtime.
- Single-file PyInstaller build bundles Python and Tcl/Tk; end-user Python installation is not required.
- Runtime user data remains outside the EXE in `%APPDATA%\\NovelScriptEngine`.
- v1.4 adds right-click system menu, 10 per-scenario save slots, full interpreter/UI-state restore, wait timer continuation and a scrollable dialogue/choice backlog.
- Save files use a SHA-256-derived scenario fingerprint; saves for distinct exact script sources are isolated.
- Save writes use a temporary file followed by atomic replace.
- Existing `.nse` command syntax and `select` branching have not changed.
- GUI smoke test covers right-click menu, save/load of pending-choice state, reconstruction of a fresh player from a save, slot deletion and backlog UI.
