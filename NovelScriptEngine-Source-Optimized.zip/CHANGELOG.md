# Changelog

## v1.3 Desktop — 画面クリックで文字送り

- Bound a click on the game canvas to the same advance behavior as the Next button.
- When typewriter animation is running, the first click completes the current line; the next click advances to the next event.
- Clicks are ignored while a choice is waiting or a timed wait is active, preventing accidental route selection or skipped pauses.
- Choice-card clicks now stop event propagation so selecting an option cannot also advance the following dialogue.
- Added GUI smoke coverage for stage clicks, typewriter completion, choice click isolation and branch progression.

## v1.2 Desktop — 画面内選択肢表示

- Moved choice options from the area below the stage into the game canvas, overlaying the background and character scene.
- Rendered each option as a clickable card inside the dialogue panel, with hover feedback and the configured text color, alignment, font and panel border.
- Automatically expands the dialogue panel for the number and wrapped length of choices; choice font size is reduced only when required to keep the list in view.
- Added number-key selection (1–9) while a choice is active.
- Preserved the existing `select` command format, order, targets and branching behavior.
- Added automated GUI smoke coverage for in-canvas placement and selection.

## v1.1 Desktop — 文字表示カスタマイズ

- Added a GUI dialog for changing the visual novel text presentation without editing scenario scripts.
- Added installed-font selection, font size and weight, dialogue/name colors, alignment and color picker controls.
- Added windowed dialogue, full-screen text overlay and subtitle layouts.
- Added adjustable dialogue panel position, height, side margins, background color, border and stipple pattern.
- Added optional typewriter text reveal with adjustable per-character speed; pressing Next completes the current line immediately.
- Added live settings preview and persistent per-user settings under `%APPDATA%\NovelScriptEngine\settings.json` on Windows.
- Added settings validation and automated regression tests.


## v1.0 Desktop

- Replaced browser GUI with a native Tkinter desktop editor.
- Added separate native test-play window.
- Added `.nse` / `.txt` open, edit, validate, save and save-as.
- Added `.nproj` v5 import and save conversion, including ordered scene blocks and character expressions.
- Added scene/label navigation, line numbers, command template palette and syntax diagnostics.
- Added branch-aware runtime for text, speaker, background, character, BGM, SE, wait, select, jump, variables, conditional jumps and endings.
- Added native Windows WAV playback through WinMM MCI.
- Bundled SVG-to-PNG conversions so Tk can display the visual novel art without third-party runtime dependencies.
- Removed browser, WebView, CDN, web server and internet runtime dependencies.
- Added Windows launch and PyInstaller build scripts.
