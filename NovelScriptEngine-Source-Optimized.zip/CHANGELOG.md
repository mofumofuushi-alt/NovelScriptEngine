# Changelog

## v1.0 Desktop

- Replaced browser GUI with a native Tkinter desktop editor.
- Added separate native test-play window.
- Added `.nse` / `.txt` open, edit, validate, save and save-as.
- Added `.nproj` v5 import and save conversion, including ordered scene blocks and character expressions.
- Added scene/label navigation, line numbers, command template palette and syntax diagnostics.
- Added branch-aware runtime for text, speaker, background, character, BGM, SE, wait, select, jump, variables, conditional jumps and endings.
- Added native Windows WAV playback through WinMM MCI.
- Bundled SVG-to-PNG conversions so Tk can display the visual novel art without third-party runtime dependencies.
- Removed browser, WebView, CDN, web server and internet runtime dependencies.
- Added Windows launch and PyInstaller build scripts.
