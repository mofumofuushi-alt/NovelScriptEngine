# GitHubへ登録してWindows EXEを自動ビルドする手順

GitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` には、ビルド用ワークフローが登録済みです。

## ソースZIPをアップロード

1. GitHubで https://github.com/mofumofuushi-alt/NovelScriptEngine を開きます。
2. Code → Add file → Upload files を選びます。
3. `NovelScriptEngine-Source-Optimized.zip` をそのままアップロードします。ZIPを展開する必要はありません。
4. Commit changes を押すと、Windows EXEの自動ビルドが始まります。

## EXEを取得

1. Actions → Build Windows EXE → 最新の実行を開きます。
2. ビルドが成功したら Artifacts の `NovelScriptEngine-Windows-x64` をダウンロードします。
3. ZIPを展開し、`NovelScriptEngine.exe` をダブルクリックします。

## 補足

- Python 3.12とPyInstallerはGitHubのWindows runner上で自動セットアップされます。
- 利用者のWindows PCへのPythonインストールは不要です。
- 完成したEXEは通常利用時にネット接続を必要としません。
- ソースZIPのアップロード後は Actions → Build Windows EXE → Run workflow で再ビルドできます。
- ビルドの前に8件の回帰テストが実行されます。
