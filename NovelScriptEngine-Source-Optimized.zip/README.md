# NovelScript Engine v1.0 Desktop（Windowsネイティブ版）

ブラウザやWebViewを使わず、Windows標準のデスクトップウィンドウとして動作するGUIシナリオエディタ／テストプレイヤーです。

## 利用者のPCにPythonは不要

完成した `NovelScriptEngine.exe` は、PythonランタイムとTk/Tclをアプリに同梱する単体実行ファイルです。**利用者はPythonをインストールする必要がありません。** 通常利用時のインターネット接続も不要です。

## Windows EXEの取得

GitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` に `NovelScriptEngine-Source-Optimized.zip` をそのままアップロードし、Commit changesを押してください。Windows runnerで自動ビルドが始まります。完了後、ActionsのArtifactsにある `NovelScriptEngine-Windows-x64` をダウンロードして展開し、`NovelScriptEngine.exe` をダブルクリックします。

GitHub Actions側でPythonとPyInstallerを自動セットアップします。利用者のWindows PCへのPython導入は不要です。ビルド時はGitHubへの接続が必要ですが、完成したEXEの通常利用は完全オフラインです。

## GUIの機能

- `.nse` / `.txt` の新規作成・編集・読み込み・保存
- 既存GUIエディタの `.nproj` 読み込み（シーン／ブロック順を保って `.nse` に変換）
- ラベル一覧とラベル位置へのジャンプ
- 命令テンプレート挿入支援
- 構文チェック（重複ラベル、存在しないジャンプ先、引数不足、引用符、未知命令警告）
- ネイティブウィンドウでのゲームテストプレイ
- 背景・立ち絵・選択肢・分岐・変数・エンディング
- WAV形式のBGM／効果音（Windowsの標準機能を使用）
- Ctrl+S 保存、Ctrl+Enter テストプレイ、Ctrl+Z/Y 編集履歴

## 同梱サンプル

- `examples/testplay_5min.nproj`：5分テストプロジェクト
- `examples/sample_5min.nse`：5分テストシナリオ
- `assets/`：SVG／WAV素材
- `assets_png/`：GUI表示用PNG素材

## ライセンス・素材クレジット

同梱素材・権利情報は `ASSET_CREDITS.md` を参照してください。
