# NovelScript Engine v1.2 Desktop（Windowsネイティブ版）

ブラウザやWebViewを使わず、Windows標準のデスクトップウィンドウとして動作するGUIシナリオエディタ／テストプレイヤーです。

## 利用者のPCにPythonは不要

完成した `NovelScriptEngine.exe` は、PythonランタイムとTk/Tclをアプリに同梱する単体実行ファイルです。**利用者はPythonをインストールする必要がありません。** 通常利用時のインターネット接続も不要です。

## Windows EXEの取得

GitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` のActionsタブから `Build Windows EXE` を実行します。完了後、Artifactsにある `NovelScriptEngine-Windows-x64` をダウンロードして展開し、`NovelScriptEngine.exe` をダブルクリックします。ソースZIPを更新してmainへ登録した場合も自動ビルドされます。

GitHub Actions側でPythonとPyInstallerを自動セットアップします。利用者のWindows PCへのPython導入は不要です。ビルド時はGitHubへの接続が必要ですが、完成したEXEの通常利用は完全オフラインです。

## GUIの機能

- `.nse` / `.txt` の新規作成・編集・読み込み・保存
- 既存GUIエディタの `.nproj` 読み込み（シーン／ブロック順を保って `.nse` に変換）
- ラベル一覧とラベル位置へのジャンプ
- 命令テンプレート挿入支援
- 構文チェック（重複ラベル、存在しないジャンプ先、引数不足、引用符、未知命令警告）
- ネイティブウィンドウでのゲームテストプレイ
- 背景・立ち絵・画面内選択肢・分岐・変数・エンディング
- **選択肢はゲーム画面（背景・立ち絵・本文ウィンドウ）内にカード状で表示**し、マウスクリックまたは数字キー（1〜9）で選択
- 選択肢の数・文字量に合わせて会話パネルを自動拡張。長い選択肢は折り返して表示
- WAV形式のBGM／効果音（Windowsの標準機能を使用）
- **画面の文字表示設定**：インストール済みフォント、文字サイズ・太さ・色、話者名色、左／中央／右揃え
- **表示レイアウト**：会話ウィンドウ／全画面テキスト／字幕スタイル
- 会話ウィンドウの位置（上／中央／下）、高さ、左右余白、背景色・枠線色・透過パターン
- タイプライター表示（1文字ずつ表示）と表示速度の変更、次へボタンで全文表示
- 表示設定ダイアログ内のプレビューと、次回起動時にも残るユーザー別設定保存
- Ctrl+S 保存、Ctrl+Enter テストプレイ、Ctrl+Z/Y 編集履歴

## 文字表示設定の保存先

Windowsでは `%APPDATA%\NovelScriptEngine\settings.json` に保存します。シナリオファイルとは独立したユーザー設定なので、`.nse` の内容や既存の命令形式は変更されません。

## 同梱サンプル

- `examples/testplay_5min.nproj`：5分テストプロジェクト
- `examples/sample_5min.nse`：5分テストシナリオ
- `assets/`：SVG／WAV素材
- `assets_png/`：GUI表示用PNG素材

## ライセンス・素材クレジット

同梱素材・権利情報は `ASSET_CREDITS.md` を参照してください。
