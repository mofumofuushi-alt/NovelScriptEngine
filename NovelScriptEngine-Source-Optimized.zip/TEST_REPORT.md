# NovelScript Engine v1.3 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 12 / 12 PASS
  - Existing .nproj → .nse import (12 labels)
  - .nse → .nproj round trip (scene labels, titles, select blocks, if/jump blocks, character expressions)
  - 5-minute test story validation (0 syntax errors)
  - Four choice combinations reach the expected endings
  - Choice event retains all option labels, order and target labels
  - Unknown command warning and missing jump target error
  - Zero-duration wait preserved and unclosed quote detected
  - Custom display layout / font / color / alignment normalization
  - Invalid display values rejected and numeric ranges clamped
  - Display preferences persist between launches
- Tkinter GUI smoke test under Xvfb: PASS
  - Native editor and game window creation
  - Background / character image load
  - Choice cards rendered inside the game canvas and remain within visible bounds
  - Six long choices fit windowed, full-screen and subtitle layouts
  - Clicking a dialogue-stage area advances to the next dialogue
  - During typewriter playback, first click reveals the full line; second click advances
  - Clicking a choice card selects its route only and does not bubble into a second advance
  - Clicking the stage while choices are waiting does not auto-select or skip
  - TRUE END route still executes as expected

## Platform checks not completed

- Manual Windows 10/11 interaction on a physical PC after this v1.3 rebuild: not yet checked.
- Existing Windows MCI WAV playback implementation is unchanged.

## Distribution

The GitHub Actions workflow compiles the standalone NovelScriptEngine.exe with Python/Tk/Tcl included. The end-user PC does not need Python. The normal runtime remains offline.
