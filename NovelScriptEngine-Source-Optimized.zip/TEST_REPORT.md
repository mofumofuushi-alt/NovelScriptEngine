# NovelScript Engine v1.0 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 8 / 8 PASS
  - Existing `.nproj` → `.nse` import (12 labels)
  - `.nse` → `.nproj` round trip (scene labels, titles, select blocks, if/jump blocks, character expressions)
  - 5-minute test story validation (0 syntax errors)
  - Four choice combinations reach the expected endings
  - Unknown command warning
  - Missing jump target error
  - Zero-duration wait remains zero
  - Unclosed quote syntax error
- Tkinter GUI smoke test under a virtual display: PASS
  - Main native GUI window creation
  - Bundled 5-minute sample load
  - Native test-play window creation
  - Background / character image load
  - Choice controls
  - TRUE END route execution

## Manual / platform-specific checks not completed

- Windows 10/11 execution: not run in this Linux build environment.
- Windows MCI WAV playback: code path implemented using the built-in WinMM API, but not verified on a physical Windows machine.
- PyInstaller Windows EXE creation: not run here. `build_windows.bat` is included to create `NovelScriptEngine.exe` on Windows.

## Important distribution note

This archive contains the native Python/Tkinter desktop application and Windows build scripts; it does **not** contain a compiled `NovelScriptEngine.exe`. Linux PyInstaller cannot create a Windows executable. To create the standalone EXE, run `build_windows.bat` on Windows. After that one-time build, the EXE runs offline without Python installed.
