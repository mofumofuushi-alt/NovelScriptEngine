# NovelScript Engine v1.8 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 21 / 21 PASS
  - `.nproj` import and `.nse` round-trip (12 labels, ordered branches and expressions)
  - 5-minute sample validation and four route combinations
  - choice event order and targets retained
  - unknown command warning, missing jump error and zero wait preserved
  - display settings normalization and persistence
  - interpreter state export / restore preserves variables, speaker and pending choices
  - per-scenario save paths and slot range validation
  - save-slot PNG path validation
  - multi-layer commands, ordering, visibility, position, removal and save/restore
  - mouth-open/closed layer settings, voice WAV command sequencing and .nproj round-trip
- Tkinter GUI smoke test under Xvfb: PASS
  - Native editor and player creation; asset and choice display
  - Existing screen-click and typewriter behavior
  - Right-click menu has Save/Load and Backlog commands
  - Save slot restores pending choices, interpreter PC and backlog
  - A fresh player window can be reconstructed from saved state (restart simulation)
  - Layer drag position, manager visibility state, and mouth-difference configuration survive player snapshot restore
  - Slots 1 and 10 save with PNG thumbnails (max 480×270), slot 10 delete also removes its PNG
  - Save screen displays the selected slot preview and opens alongside backlog
  - Multi-layer sprites render, drag independently, and display in the layer manager; visibility toggle verified
  - Selection after restoring a saved choice follows the correct branch and is recorded

## Windows checks

- Linux-side Python syntax check and unit tests passed; GUI smoke test passed under Xvfb.
- GitHub Actions Windows runner is expected to execute the same tests before PyInstaller compilation.
- Manual Windows 10/11 physical-device check is not yet performed for this release.

## Distribution

The Windows Actions build includes Pillow-based game-canvas capture in a single `NovelScriptEngine.exe` with Python/Tk/Tcl bundled. End-user Python installation is not required. Save files and display preferences are stored outside the EXE under `%APPDATA%\\NovelScriptEngine` and survive EXE updates.

## v1.8 regression results

- `python -m py_compile app.py`: passed.
- `python -m unittest discover -s tests -p "test_*.py" -v`: 21 tests passed.
- `python tests/gui_smoke.py` on a virtual display: passed.
- Confirmed fixed `left` / `center` / `right` character anchors, removal of character coordinate state, v1.6 saved-coordinate migration, `.nproj` conversion to fixed anchors, click-through behavior on character art, and no drag movement of overlay layers.
- Confirmed v1.7 layer manager, visibility toggle, lip/voice layer state and save restoration remain operational.
