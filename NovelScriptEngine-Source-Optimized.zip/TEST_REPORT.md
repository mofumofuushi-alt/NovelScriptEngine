# NovelScript Engine v1.1 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 11 / 11 PASS
  - Existing `.nproj` → `.nse` import (12 labels)
  - `.nse` → `.nproj` round trip (scene labels, titles, select blocks, if/jump blocks, character expressions)
  - 5-minute test story validation (0 syntax errors)
  - Four choice combinations reach the expected endings
  - Unknown command warning
  - Missing jump target error
  - Zero-duration wait remains zero
  - Unclosed quote syntax error
  - Custom display layout / font / color / alignment normalization
  - Invalid display values rejected and numeric ranges clamped
  - Display preferences persist between launches
- Tkinter GUI smoke test under a virtual display: PASS
  - Main native GUI window creation
  - Bundled 5-minute sample load
  - Native test-play window creation
  - Background / character image load
  - Choice controls and TRUE END route execution
  - Display settings dialog and live preview creation
  - Typewriter reveal and Next-to-complete behavior

## Platform checks not completed

- Windows 10/11 manual screen interaction after this v1.1 rebuild: not yet checked on a physical Windows PC.
- The existing WindowsMCI WAV playback implementation is unchanged.

## Distribution

The Windows GitHub Actions workflow compiles the standalone `NovelScriptEngine.exe` with Python/Tk/Tcl included. The end-user PC does not need Python.
