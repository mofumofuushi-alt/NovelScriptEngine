# NovelScript Engine v1.5 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 14 / 14 PASS
  - `.nproj` import and `.nse` round-trip (12 labels, ordered branches and expressions)
  - 5-minute sample validation and four route combinations
  - choice event order and targets retained
  - unknown command warning, missing jump error and zero wait preserved
  - display settings normalization and persistence
  - interpreter state export / restore preserves variables, speaker and pending choices
  - per-scenario save paths and slot range validation
  - save-slot PNG path validation
- Tkinter GUI smoke test under Xvfb: PASS
  - Native editor and player creation; asset and choice display
  - Existing screen-click and typewriter behavior
  - Right-click menu has Save/Load and Backlog commands
  - Save slot restores pending choices, interpreter PC and backlog
  - A fresh player window can be reconstructed from saved state (restart simulation)
  - Slots 1 and 10 save with PNG thumbnails (max 480×270), slot 10 delete also removes its PNG
  - Save screen displays the selected slot preview and opens alongside backlog
  - Selection after restoring a saved choice follows the correct branch and is recorded

## Windows checks

- GitHub Actions Windows runner executes unit and GUI smoke tests before PyInstaller compilation.
- Manual Windows 10/11 physical-device check is not yet performed for this release.

## Distribution

The Windows Actions build includes Pillow-based game-canvas capture in a single `NovelScriptEngine.exe` with Python/Tk/Tcl bundled. End-user Python installation is not required. Save files and display preferences are stored outside the EXE under `%APPDATA%\\NovelScriptEngine` and survive EXE updates.
