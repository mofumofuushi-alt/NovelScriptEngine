# NovelScript Engine v1.2 Desktop — Test Report

## Automated tests

- Python syntax compilation: PASS
- Unit tests: 12 / 12 PASS
  - Existing `.nproj` → `.nse` import (12 labels)
  - `.nse` → `.nproj` round trip (scene labels, titles, select blocks, if/jump blocks, character expressions)
  - 5-minute test story validation (0 syntax errors)
  - Four choice combinations reach the expected endings
  - Choice event retains all option labels, order and target labels
  - Unknown command warning
  - Missing jump target error
  - Zero-duration wait remains zero
  - Unclosed quote syntax error
  - Custom display layout / font / color / alignment normalization
  - Invalid display values rejected and numeric ranges clamped
  - Display preferences persist between launches
- Tkinter GUI smoke test under a virtual display: PASS
  - Main native GUI editor and game window creation
  - Background / character image load
  - Choice cards rendered inside the game canvas (no external choice frame)
  - Choice cards remain within the visible canvas bounds
  - Six long choices fit inside windowed, full-screen and subtitle layouts at all three panel positions
  - Click-equivalent choice selection follows the expected TRUE END route
  - Existing display settings dialog, preview and typewriter behavior remain available

## Platform checks not completed

- Manual Windows 10/11 interaction on a physical PC after this v1.2 rebuild: not yet checked.
- Existing Windows MCI WAV playback implementation is unchanged.

## Distribution

The GitHub Actions workflow compiles the standalone `NovelScriptEngine.exe` with Python/Tk/Tcl included. The end-user PC does not need Python. The normal runtime remains offline.
