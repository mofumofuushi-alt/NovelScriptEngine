# Windows EXEの取得方法（利用者PCにPython不要）

## GitHub Actionsを使ったビルド

1. `NovelScriptEngine-Source-Optimized.zip` をGitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` のルートへアップロードします。ZIPは展開しないでください。
2. Commit changesを押すと、`Build Windows EXE` ワークフローが自動的に起動します。
3. Actionsの実行結果を開き、成功したらArtifactsから `NovelScriptEngine-Windows-x64` をダウンロードします。
4. ZIPを展開して `NovelScriptEngine.exe` をダブルクリックします。

GitHubのWindows runnerがPython 3.12とPyInstallerを自動的に準備します。利用者のWindows PCにPythonを導入する必要はありません。

## 完成EXEの仕様

- Windows 10 / 11 x64向け
- PythonランタイムとTk/TclをEXEに同梱
- Pythonの事前インストール不要
- 通常利用時のネット接続不要
- 背景・立ち絵・サンプル素材を同梱

## 注意

この開発環境はLinuxのため、Windows PE形式のEXEをここで直接生成・実行確認することはできません。GitHub Actionsのビルド完了後、Windows実機で初回起動を確認してください。
