# Windows EXEの取得方法（Pythonインストール不要）

## GitHub Actionsを使ったビルド

このリポジトリでは、GitHub ActionsのWindows 2022 runner上でEXEを自動生成します。利用者のPCにPythonを入れる必要はありません。

1. GitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` の **Actions** タブを開きます。
2. **Build Windows EXE** を選び、**Run workflow** を実行します。ソースZIPを更新してmainへ反映した場合は自動でも起動します。
3. 成功した実行を開き、Artifactsから `NovelScriptEngine-Windows-x64` をダウンロードします。
4. ZIPを展開して `NovelScriptEngine.exe` をダブルクリックします。

## 完成EXEの仕様

- Windows 10 / 11 x64向け
- PythonランタイムとTk/TclをEXEに同梱
- Pythonの事前インストール不要
- 通常利用時のネット接続不要
- 背景・立ち絵・サンプル素材を同梱
- 選択肢はゲーム画面内にカード状に表示。クリックまたは数字キー1〜9で選択

## ビルド時の注意

ビルド時のみGitHubのWindows runner上でPython 3.12とPyInstallerを準備するため、GitHubへのネット接続が必要です。生成したEXEの通常利用ではネット接続を行いません。

## ゲーム画面の操作（v1.3）

本文表示中はゲーム画面内をクリックすると文字送りします。タイプライター表示中の最初のクリックは全文表示、次のクリックで続きへ進みます。選択肢待機中およびwait中は画面クリックでは進行しません。
