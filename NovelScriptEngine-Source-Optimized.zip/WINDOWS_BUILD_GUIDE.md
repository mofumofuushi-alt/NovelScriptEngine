# Windows EXEの取得方法（Pythonインストール不要）

## GitHub Actionsを使ったビルド

1. GitHubリポジトリ `mofumofuushi-alt/NovelScriptEngine` の **Actions** タブを開きます。
2. **Build Windows EXE** を選び、**Run workflow** を実行します。ソースZIPを更新してmainへ登録した場合は自動でも起動します。
3. 成功した実行を開き、Artifactsから `NovelScriptEngine-Windows-x64` をダウンロードします。
4. ZIPを展開し、`NovelScriptEngine.exe` をダブルクリックします。

## 完成EXEの仕様

- Windows 10 / 11 x64向け
- PythonランタイムとTk/TclをEXEに同梱
- Pythonの事前インストール不要
- 通常利用時のネット接続不要
- 背景・立ち絵・サンプル素材を同梱
- 右クリックメニュー、10スロットのセーブ／ロード、保存時画面サムネイル、バックログを搭載

## ゲーム画面の操作

- 本文表示中にゲーム画面を左クリック：次の文章へ
- タイプライター表示中の左クリック：1回目で全文表示、2回目で次へ
- 選択肢カードを左クリック：選択した分岐へ
- 選択肢待機中／wait中の背景クリック：進行しない
- ゲーム画面を右クリック：セーブ・ロード／バックログメニュー

## セーブデータ

Windowsの `%APPDATA%\NovelScriptEngine\saves\` 以下にシナリオごとのフォルダを作成し、最大10スロットに保存します。保存時のゲーム画面は各スロットの `slot_01.png` 〜 `slot_10.png` として同じフォルダに保存され、セーブ画面右側にプレビューされます。EXEの更新・再ビルドでは削除されません。表示設定は `%APPDATA%\NovelScriptEngine\settings.json` に保存されます。

## ビルド時の注意

ビルド時のみGitHubのWindows runner上でPython 3.12とPyInstallerを準備するため、GitHubへのネット接続が必要です。生成したEXEの通常利用ではネット接続を行いません。
