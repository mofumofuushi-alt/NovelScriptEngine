# -*- coding: utf-8 -*-
"""NovelScript Engine v1.1 - native Windows desktop editor and player.
No browser, web server, CDN, or network access is used.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser, font as tkfont
from pathlib import Path
from dataclasses import dataclass
from typing import Any

APP_NAME = "NovelScript Engine"
APP_VERSION = "1.1 Desktop"

DEFAULT_DISPLAY_SETTINGS: dict[str, Any] = {
    "layout": "window",
    "font_family": "Meiryo",
    "font_size": 16,
    "font_weight": "normal",
    "text_color": "#ffffff",
    "text_align": "left",
    "name_color": "#ffffff",
    "panel_color": "#080d18",
    "panel_border": "#a8bfdc",
    "panel_pattern": "gray50",
    "panel_position": "bottom",
    "panel_height": 30,
    "side_margin": 3,
    "typewriter": False,
    "type_speed": 45,
}


def display_settings_path() -> Path:
    """Return a per-user writable settings path (outside the EXE bundle)."""
    if sys.platform == "win32":
        root = Path(os.environ.get("APPDATA", str(Path.home())))
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))
    return root / "NovelScriptEngine" / "settings.json"


def normalize_display_settings(value: Any) -> dict[str, Any]:
    """Validate display preferences from disk or the settings dialog."""
    data = dict(DEFAULT_DISPLAY_SETTINGS)
    if isinstance(value, dict):
        data.update({k: v for k, v in value.items() if k in data})
    choices = {
        "layout": {"window", "fullscreen", "subtitle"},
        "font_weight": {"normal", "bold"},
        "text_align": {"left", "center", "right"},
        "panel_pattern": {"", "gray25", "gray50", "gray75"},
        "panel_position": {"top", "middle", "bottom"},
    }
    for key, allowed in choices.items():
        if data[key] not in allowed:
            data[key] = DEFAULT_DISPLAY_SETTINGS[key]
    for key, low, high in (("font_size", 10, 48), ("panel_height", 15, 60), ("side_margin", 1, 20), ("type_speed", 10, 200)):
        try:
            data[key] = max(low, min(high, int(data[key])))
        except (TypeError, ValueError):
            data[key] = DEFAULT_DISPLAY_SETTINGS[key]
    for key in ("text_color", "name_color", "panel_color", "panel_border"):
        if not isinstance(data[key], str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", data[key]):
            data[key] = DEFAULT_DISPLAY_SETTINGS[key]
    data["font_family"] = str(data["font_family"] or "Meiryo")[:80]
    data["typewriter"] = bool(data["typewriter"])
    return data


def load_display_settings() -> dict[str, Any]:
    path = display_settings_path()
    try:
        return normalize_display_settings(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError, TypeError):
        return dict(DEFAULT_DISPLAY_SETTINGS)


def save_display_settings(settings: dict[str, Any]) -> None:
    path = display_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(normalize_display_settings(settings), ensure_ascii=False, indent=2), encoding="utf-8")
COMMANDS = {
    "text": 'text "台詞を入力してください。"',
    "msg": 'msg "台詞を入力してください。"',
    "name": 'name "話者名"',
    "bg": 'bg "assets/bg_station.svg"',
    "chara": 'chara "mio" "assets/mio_neutral.svg" center',
    "bgm": 'bgm "assets/bgm_station.wav" 50',
    "se": 'se "assets/se_station_chime.wav" 60',
    "wait": 'wait 500',
    "select": 'select "選択肢の文章" next_label',
    "jump": 'jump next_label',
    "set": 'set route 1',
    "inc": 'inc route 1',
    "if": 'if route == 1 jump true_end',
    "endflag": 'endflag true_end',
    "end": "end",
}


def resource_path(*parts: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base.joinpath(*parts)


def quote(value: Any) -> str:
    s = str(value if value is not None else "")
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def parse_script(source: str) -> list[dict[str, Any]]:
    commands: list[dict[str, Any]] = []
    for line_no, original in enumerate(source.replace("\ufeff", "").splitlines(), 1):
        line = original.strip()
        if not line or line.startswith(";") or line.startswith("//"):
            continue
        if line.startswith("*"):
            label = line[1:].strip()
            commands.append({"op": "label", "args": [label], "line": line_no})
            continue
        try:
            tokens = shlex.split(line, posix=True)
        except ValueError as exc:
            raise ValueError(f"{line_no}行目: {exc}") from exc
        if tokens:
            op = tokens[0].lower()
            args = tokens[1:]
            if op in {"text", "msg", "name"}:
                args = [value.replace("\\n", "\n") for value in args]
            commands.append({"op": op, "args": args, "line": line_no})
    return commands


def validate_script(source: str) -> list[tuple[str, int, str]]:
    issues: list[tuple[str, int, str]] = []
    labels: dict[str, int] = {}
    references: list[tuple[int, str, str]] = []
    known = {"label", "text", "msg", "name", "bg", "chara", "bgm", "se", "wait", "jump", "select", "set", "inc", "if", "endif", "endflag", "clear", "end"}
    for no, original in enumerate(source.replace("\ufeff", "").splitlines(), 1):
        line = original.strip()
        if not line or line.startswith(";") or line.startswith("//"):
            continue
        if line.startswith("*"):
            label = line[1:].strip()
            if not label:
                issues.append(("エラー", no, "ラベル名が空です"))
            elif label in labels:
                issues.append(("エラー", no, f"ラベル '{label}' が重複しています（{labels[label]}行目）"))
            else:
                labels[label] = no
            continue
        try:
            tokens = shlex.split(line, posix=True)
        except ValueError as exc:
            issues.append(("エラー", no, f"引用符の構文エラー: {exc}"))
            continue
        if not tokens:
            continue
        op, args = tokens[0].lower(), tokens[1:]
        if op not in known:
            issues.append(("警告", no, f"未知の命令 '{op}'（実行時には無視される可能性があります）"))
            continue
        minimum = {"text": 1, "msg": 1, "name": 1, "bg": 1, "chara": 1, "bgm": 1, "se": 1, "wait": 1, "jump": 1, "select": 2, "set": 2, "inc": 1, "if": 5, "endflag": 1}.get(op, 0)
        if len(args) < minimum:
            issues.append(("エラー", no, f"命令 '{op}' の引数が不足しています（必要 {minimum} 個）"))
            continue
        if op == "jump":
            references.append((no, args[0], "jump"))
        elif op == "select":
            references.append((no, args[1], "select"))
        elif op == "if":
            if len(args) < 5 or args[-2] != "jump":
                issues.append(("エラー", no, "if は 'if 変数 演算子 値 jump ラベル' の形式で記述してください"))
            else:
                references.append((no, args[-1], "if"))
        if op == "chara" and args[0] not in {"off", "none"} and len(args) < 3:
            issues.append(("警告", no, "chara の表示には actor・画像パス・位置の指定を推奨します"))
    for no, target, kind in references:
        if target not in labels:
            issues.append(("エラー", no, f"{kind} の遷移先ラベル '{target}' が見つかりません"))
    return issues


def project_to_nse(project: dict[str, Any]) -> str:
    """Import the existing GUI project's ordered scene/block data to v0.1 NSE syntax."""
    out = [f"; Imported NovelScript project: {project.get('name', 'Untitled')}", "; Native desktop editor / v0.1 compatible command syntax", ""]
    for scene in project.get("scenes", []):
        label = str(scene.get("label") or scene.get("id") or "scene")
        out.extend([f"*{label}", f"; {scene.get('title', label)}"])
        for block in scene.get("blocks", []):
            kind = block.get("type")
            if kind == "bg": out.append("bg " + quote(block.get("path", "")))
            elif kind == "bgm":
                if block.get("mode") == "stop": out.append("bgm stop")
                else: out.append(f"bgm {quote(block.get('path',''))} {block.get('volume',100)}")
            elif kind == "se": out.append(f"se {quote(block.get('path',''))} {block.get('volume',100)}")
            elif kind == "chara":
                if block.get("mode") == "hide": out.append("chara off")
                else: out.append(f"chara {quote(block.get('actor','chara'))} {quote(block.get('path',''))} {block.get('position','center')}")
            elif kind == "speaker": out.append("name " + quote(block.get("value", "")))
            elif kind == "text": out.append("text " + quote(block.get("text", "")))
            elif kind == "select": out.append(f"select {quote(block.get('text',''))} {block.get('target','')}")
            elif kind == "jump": out.append(f"jump {block.get('target','')}")
            elif kind == "set": out.append(f"set {block.get('variable','var')} {quote(block.get('value','0'))}")
            elif kind == "inc": out.append(f"inc {block.get('variable','var')} {block.get('value',1)}")
            elif kind == "if": out.append(f"if {block.get('variable','var')} {block.get('operator','==')} {quote(block.get('value','0'))} jump {block.get('target','')}")
            elif kind == "endflag": out.append(f"endflag {block.get('ending','ending')}")
            elif kind == "end": out.append("end")
            elif kind == "wait": out.append(f"wait {block.get('duration',500)}")
            elif kind == "clear": out.append("clear")
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def nse_to_project(source: str, name: str = "NovelScript Project") -> dict[str, Any]:
    """Serialize supported NSE commands into the existing v5 .nproj scene/block format."""
    commands = parse_script(source)
    scenes: list[dict[str, Any]] = []
    assets: list[dict[str, Any]] = []
    asset_ids: dict[tuple[str, str], str] = {}

    def scene_for(label: str) -> dict[str, Any]:
        scene = {"id": f"scene_{label}", "label": label, "title": label, "blocks": [], "conditions": [], "choices": [], "flow": "continue", "flowTarget": ""}
        scenes.append(scene)
        return scene

    current = None
    for cmd in commands:
        op, a = cmd["op"], cmd["args"]
        if op == "label":
            current = scene_for(a[0] if a else f"scene_{len(scenes)+1}")
            continue
        if current is None:
            current = scene_for("start")
        block: dict[str, Any] | None = None
        if op == "text" or op == "msg": block = {"type": "text", "text": " ".join(a)}
        elif op == "name": block = {"type": "speaker", "value": " ".join(a), "text": ""}
        elif op == "bg": block = {"type": "bg", "path": a[0] if a else ""}
        elif op == "bgm": block = {"type": "bgm", "mode": "stop" if not a or a[0] in {"stop", "off"} else "play", "path": "" if not a or a[0] in {"stop", "off"} else a[0], "volume": int(float(a[1])) if len(a)>1 else 100}
        elif op == "se": block = {"type": "se", "path": a[0] if a else "", "volume": int(float(a[1])) if len(a)>1 else 100}
        elif op == "chara": block = {"type": "chara", "mode": "hide" if not a or a[0] in {"off", "none"} else "show", "actor": a[0] if a else "", "path": a[1] if len(a)>1 else "", "position": a[2] if len(a)>2 else "center"}
        elif op == "wait": block = {"type": "wait", "duration": int(float(a[0])) if a else 500}
        elif op == "select" and len(a)>=2: block = {"type": "select", "text": " ".join(a[:-1]), "target": a[-1]}
        elif op == "jump" and a: block = {"type": "jump", "target": a[0]}
        elif op == "set" and len(a)>=2: block = {"type": "set", "variable": a[0], "value": " ".join(a[1:])}
        elif op == "inc" and a: block = {"type": "inc", "variable": a[0], "value": int(float(a[1])) if len(a)>1 else 1}
        elif op == "if" and len(a)>=5 and a[-2] == "jump": block = {"type": "if", "variable": a[0], "operator": a[1], "value": a[2], "target": a[-1]}
        elif op == "endflag": block = {"type": "endflag", "ending": a[0] if a else "ending"}
        elif op == "end": block = {"type": "end"}
        elif op == "clear": block = {"type": "clear"}
        elif op == "endif": continue
        if block is None: continue
        block["id"] = f"b{len(current['blocks'])+1}_{current['label']}"
        if block["type"] in {"bg", "bgm", "se", "chara"} and block.get("path"):
            kind = block["type"]
            path = block["path"]
            if kind == "chara":
                actor = block.get("actor") or "chara"
                key = (kind, actor)
                aid = asset_ids.get(key)
                if not aid:
                    aid = f"chara_{actor}"
                    asset_ids[key] = aid
                    assets.append({"id": aid, "name": actor, "type": kind, "path": path, "fileName": Path(path).name, "expressions": []})
                asset_entry = next(x for x in assets if x["id"] == aid)
                if path != asset_entry["path"] and not any(x["path"] == path for x in asset_entry["expressions"]):
                    asset_entry["expressions"].append({"id": f"{aid}_{Path(path).stem}", "name": Path(path).stem, "path": path, "fileName": Path(path).name})
            else:
                key = (kind, path)
                aid = asset_ids.get(key)
                if not aid:
                    aid = f"{kind}_{Path(path).stem}"
                    asset_ids[key] = aid
                    assets.append({"id": aid, "name": Path(path).stem, "type": kind, "path": path, "fileName": Path(path).name, "expressions": []})
            block["assetId"] = aid
        current["blocks"].append(block)
    if not scenes: scene_for("start")
    # The existing importer writes a scene title in the first comment after each label.
    source_lines = source.replace("\ufeff", "").splitlines()
    for idx, line in enumerate(source_lines):
        stripped = line.strip()
        if stripped.startswith("*"):
            label = stripped[1:].strip()
            for follow in source_lines[idx + 1:]:
                value = follow.strip()
                if not value:
                    continue
                if value.startswith(";"):
                    title = value[1:].strip()
                    scene = next((x for x in scenes if x["label"] == label), None)
                    if scene and title and not title.startswith("Imported NovelScript") and not title.startswith("Original sample"):
                        scene["title"] = title
                    break
                if value.startswith("*") or not value.startswith("//"):
                    break
    return {"version": 5, "name": name, "assets": assets, "scenes": scenes}


def parse_value(value: str) -> Any:
    if value == "true": return True
    if value == "false": return False
    try:
        if value.strip() != "":
            return float(value) if "." in value else int(value)
    except ValueError:
        pass
    return value


def compare_values(left: Any, op: str, right: Any) -> bool:
    try:
        if op in {"==", "="}: return left == right or str(left) == str(right)
        if op == "!=": return not (left == right or str(left) == str(right))
        a, b = float(left), float(right)
        return {">": a > b, "<": a < b, ">=": a >= b, "<=": a <= b}.get(op, False)
    except (TypeError, ValueError):
        return False


class ScenarioEngine:
    """Small deterministic interpreter shared by native player and automated tests."""
    def __init__(self, source: str):
        self.commands = parse_script(source)
        self.labels = {c["args"][0]: i for i, c in enumerate(self.commands) if c["op"] == "label" and c["args"]}
        self.pc = 0
        self.variables: dict[str, Any] = {}
        self.speaker = ""
        self.background = ""
        self.character = ""
        self.character_position = "center"
        self.bgm = ""
        self.bgm_volume = 100
        self.last_se = ""
        self.last_se_volume = 100
        self.ending_flags: set[str] = set()
        self.waiting_choices: list[tuple[str, str]] | None = None
        self.ended = False
        self.steps = 0

    def advance(self, choice_index: int | None = None) -> dict[str, Any]:
        if self.ended:
            return {"type": "end"}
        if self.waiting_choices is not None:
            if choice_index is None:
                return {"type": "choices", "choices": self.waiting_choices}
            if choice_index < 0 or choice_index >= len(self.waiting_choices):
                raise ValueError("選択肢の番号が不正です")
            target = self.waiting_choices[choice_index][1]
            self.waiting_choices = None
            if target not in self.labels:
                raise ValueError(f"ラベルがありません: {target}")
            self.pc = self.labels[target] + 1
        while self.pc < len(self.commands):
            self.steps += 1
            if self.steps > 20000:
                raise RuntimeError("無限ループの可能性があります（20,000命令で停止）")
            cmd = self.commands[self.pc]; self.pc += 1
            op, a = cmd["op"], cmd["args"]
            if op == "label" or op == "endif": continue
            if op in {"text", "msg"}:
                return {"type": "text", "text": " ".join(a), "speaker": self.speaker}
            if op == "name": self.speaker = " ".join(a); continue
            if op == "bg": self.background = a[0] if a else ""; continue
            if op == "chara":
                if not a or a[0] in {"off", "none"}: self.character = ""
                else:
                    self.character = a[1] if len(a) > 1 else ""
                    self.character_position = a[2] if len(a) > 2 else "center"
                continue
            if op == "bgm":
                self.bgm = "" if not a or a[0] in {"stop", "off"} else a[0]
                self.bgm_volume = max(0, min(100, int(float(a[1])))) if len(a) > 1 else 100
                continue
            if op == "se":
                self.last_se = a[0] if a else ""
                self.last_se_volume = max(0, min(100, int(float(a[1])))) if len(a) > 1 else 100
                continue
            if op == "wait": return {"type": "wait", "ms": max(0, int(float(a[0] or 0)))}
            if op == "jump":
                target = a[0]
                if target not in self.labels: raise ValueError(f"ラベルがありません: {target}")
                self.pc = self.labels[target] + 1; continue
            if op == "select":
                choices = [(" ".join(a[:-1]), a[-1])]
                while self.pc < len(self.commands) and self.commands[self.pc]["op"] == "select":
                    nxt = self.commands[self.pc]["args"]
                    if len(nxt) < 2: raise ValueError("選択肢の引数が不足しています")
                    choices.append((" ".join(nxt[:-1]), nxt[-1])); self.pc += 1
                self.waiting_choices = choices
                return {"type": "choices", "choices": choices}
            if op == "set": self.variables[a[0]] = parse_value(" ".join(a[1:])); continue
            if op == "inc": self.variables[a[0]] = (float(self.variables.get(a[0], 0)) + float(a[1] if len(a) > 1 else 1)); continue
            if op == "if":
                if len(a) >= 5 and a[-2] == "jump" and compare_values(self.variables.get(a[0], 0), a[1], parse_value(a[2])):
                    target = a[-1]
                    if target not in self.labels: raise ValueError(f"ラベルがありません: {target}")
                    self.pc = self.labels[target] + 1
                continue
            if op == "endflag": self.ending_flags.add(a[0] if a else "ending"); continue
            if op == "clear": continue
            if op == "end": self.ended = True; return {"type": "end"}
            # Keep importer compatibility: unsupported future commands fail visibly.
            raise ValueError(f"未対応命令 '{op}'（{cmd['line']}行目）")
        self.ended = True
        return {"type": "end"}


class WindowsMciAudio:
    """Windows waveaudio mixer using the built-in WinMM MCI API (BGM + SE channels)."""
    def __init__(self, window: tk.Misc):
        import ctypes
        self.ctypes = ctypes
        self.window = window
        self.winmm = ctypes.WinDLL("winmm")
        self.winmm.mciSendStringW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p]
        self.winmm.mciSendStringW.restype = ctypes.c_uint
        self.bgm_alias = "nse_bgm"
        self.bgm_path = ""
        self.se_counter = 0
        self.open_aliases: set[str] = set()

    def send(self, command: str) -> bool:
        try:
            result = self.winmm.mciSendStringW(command, None, 0, None)
            return result == 0
        except Exception:
            return False

    def open_wave(self, path: Path, alias: str) -> bool:
        if alias in self.open_aliases:
            self.send(f"close {alias}"); self.open_aliases.discard(alias)
        ok = self.send(f'open "{str(path).replace(chr(34), "")}" type waveaudio alias {alias}')
        if ok: self.open_aliases.add(alias)
        return ok

    def play_bgm(self, path: Path, volume: int = 100):
        if self.bgm_path == str(path) and self.bgm_alias in self.open_aliases:
            return
        self.stop_bgm()
        if self.open_wave(path, self.bgm_alias):
            self.send(f"setaudio {self.bgm_alias} volume to {int(volume * 10)}")
            self.send(f"play {self.bgm_alias} repeat")
            self.bgm_path = str(path)

    def stop_bgm(self):
        if self.bgm_alias in self.open_aliases:
            self.send(f"stop {self.bgm_alias}"); self.send(f"close {self.bgm_alias}")
            self.open_aliases.discard(self.bgm_alias)
        self.bgm_path = ""

    def play_se(self, path: Path, volume: int = 100):
        self.se_counter += 1
        alias = f"nse_se_{self.se_counter}"
        if not self.open_wave(path, alias): return
        self.send(f"setaudio {alias} volume to {int(volume * 10)}")
        self.send(f"play {alias}")
        try:
            import wave
            with wave.open(str(path), "rb") as wav:
                duration = int(1000 * wav.getnframes() / max(1, wav.getframerate()))
        except Exception:
            duration = 5000
        def cleanup():
            if alias in self.open_aliases:
                self.send(f"stop {alias}"); self.send(f"close {alias}")
                self.open_aliases.discard(alias)
        try: self.window.after(max(500, duration + 250), cleanup)
        except tk.TclError: cleanup()

    def close(self):
        self.stop_bgm()
        for alias in tuple(self.open_aliases):
            self.send(f"stop {alias}"); self.send(f"close {alias}")
            self.open_aliases.discard(alias)


class NativePlayer:
    def __init__(self, app: "NovelScriptApp", source: str, base_dir: Path):
        self.app = app
        self.base_dir = base_dir
        self.engine = ScenarioEngine(source)
        self.window = tk.Toplevel(app.root)
        self.window.title("NovelScript Engine - テストプレイ")
        self.window.geometry("1040x760")
        self.window.minsize(820, 620)
        self.window.configure(bg="#111827")
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self._bg_img = None; self._ch_img = None
        self._bg_ref = None; self._ch_ref = None
        self._bgm_path = ""
        self._last_bgm = ""
        self._last_se = ""
        self.display_settings = normalize_display_settings(app.display_settings)
        self._typing_job = None
        self._typing_text = ""
        self._typing_speaker = ""
        self._typing_index = 0
        self._dialog_text_id = None
        self._resize_job = None
        try:
            self.audio = WindowsMciAudio(self.window) if sys.platform == "win32" else None
        except Exception:
            self.audio = None
        self.canvas = tk.Canvas(self.window, width=960, height=540, bg="#202938", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=12, pady=(12, 6))
        foot = ttk.Frame(self.window, padding=(12, 6, 12, 12)); foot.pack(fill="x")
        self.status = ttk.Label(foot, text="テストプレイ中", anchor="w"); self.status.pack(side="left", fill="x", expand=True)
        self.next_btn = ttk.Button(foot, text="次へ ▶", command=self.next); self.next_btn.pack(side="right")
        self.choice_frame = ttk.Frame(self.window, padding=(14, 0, 14, 10)); self.choice_frame.pack(fill="x")
        self.window.bind("<space>", lambda e: self.next())
        self.window.bind("<Return>", lambda e: self.next())
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.refresh_stage()
        self.step()

    def asset_path(self, rel: str) -> Path | None:
        if not rel: return None
        candidates = [self.base_dir / rel, resource_path(rel)]
        for p in candidates:
            if p.is_file(): return p
        return None

    def image_path(self, rel: str) -> Path | None:
        p = self.asset_path(rel)
        if p is None: return None
        if p.suffix.lower() == ".svg":
            png = resource_path("assets_png", p.stem + ".png")
            if png.is_file(): return png
            # SVG files not part of the bundled set are not converted at runtime.
            return None
        return p if p.suffix.lower() == ".png" else None

    def _on_canvas_resize(self, _event=None):
        if self._resize_job is not None:
            try: self.window.after_cancel(self._resize_job)
            except tk.TclError: pass
        self._resize_job = self.window.after(90, self._redraw_current)

    def _redraw_current(self):
        self._resize_job = None
        if self.window.winfo_exists():
            visible = self._typing_text[:self._typing_index] if self._typing_job is not None else self._typing_text
            self.refresh_stage(visible, self._typing_speaker)

    def refresh_stage(self, text: str = "", speaker: str = ""):
        self.canvas.delete("all")
        self._dialog_text_id = None
        w = max(self.canvas.winfo_width(), 640); h = max(self.canvas.winfo_height(), 360)
        settings = self.display_settings
        bg = self.image_path(self.engine.background)
        if bg and str(bg) != self._bg_ref:
            try: self._bg_img = tk.PhotoImage(file=str(bg)); self._bg_ref = str(bg)
            except tk.TclError: self._bg_img = None
        if self._bg_img:
            self.canvas.create_image(w//2, h//2, image=self._bg_img)
        else:
            self.canvas.create_rectangle(0, 0, w, h, fill="#202938", outline="")
            self.canvas.create_text(w//2, h//3, text="NovelScript Engine", fill="#91a4c1", font=(settings["font_family"], 24, "bold"))
        ch = self.image_path(self.engine.character)
        if ch and str(ch) != self._ch_ref:
            try: self._ch_img = tk.PhotoImage(file=str(ch)); self._ch_ref = str(ch)
            except tk.TclError: self._ch_img = None
        if self.engine.character and self._ch_img:
            x = {"left": w*0.25, "right": w*0.75}.get(self.engine.character_position, w*0.5)
            self.canvas.create_image(int(x), int(h*0.77), image=self._ch_img, anchor="s")

        layout = settings["layout"]
        margin = max(12, int(w * settings["side_margin"] / 100))
        panel_h = max(90, int(h * settings["panel_height"] / 100))
        if layout == "fullscreen":
            panel_top, panel_bottom = int(h * 0.08), int(h * 0.92)
            panel_left, panel_right = margin, w - margin
        else:
            if settings["panel_position"] == "top":
                panel_top = 18
            elif settings["panel_position"] == "middle":
                panel_top = max(18, (h - panel_h) // 2)
            else:
                panel_top = max(18, h - panel_h - 18)
            panel_bottom = min(h - 12, panel_top + panel_h)
            panel_left, panel_right = margin, w - margin
        pattern = settings["panel_pattern"]
        self.canvas.create_rectangle(
            panel_left, panel_top, panel_right, panel_bottom,
            fill=settings["panel_color"], outline=settings["panel_border"], width=2,
            stipple=pattern if pattern else ""
        )

        inner_x = panel_left + max(18, int((panel_right-panel_left) * 0.035))
        inner_w = max(120, panel_right-panel_left-2*(inner_x-panel_left))
        name_font = (settings["font_family"], max(9, settings["font_size"]-3), "bold")
        text_font = (settings["font_family"], settings["font_size"], settings["font_weight"])
        align = settings["text_align"]
        anchor = {"left": "nw", "center": "n", "right": "ne"}[align]
        text_x = {"left": inner_x, "center": (panel_left+panel_right)//2, "right": panel_right-(inner_x-panel_left)}[align]

        if speaker:
            if layout == "subtitle":
                name_y = panel_top + 10
                text_y = name_y + max(22, settings["font_size"]+5)
            elif layout == "fullscreen":
                name_y = panel_top + 24
                text_y = panel_top + int((panel_bottom-panel_top)*0.28)
            else:
                name_y = panel_top + 10
                text_y = max(panel_top + 38, panel_top + int(panel_h*0.28))
            self.canvas.create_text(
                inner_x, name_y, text=speaker, anchor="nw",
                fill=settings["name_color"], font=name_font
            )
        else:
            if layout == "subtitle": text_y = panel_top + 12
            elif layout == "fullscreen": text_y = panel_top + int((panel_bottom-panel_top)*0.28)
            else: text_y = panel_top + max(18, int(panel_h*0.28))

        if layout == "subtitle":
            text_y = min(panel_bottom-12, text_y)
        self._dialog_text_id = self.canvas.create_text(
            text_x, text_y, text=text, anchor=anchor, width=inner_w,
            fill=settings["text_color"], font=text_font, justify=align
        )
        self.status.configure(text=f"シーン: {self.engine.pc}/{len(self.engine.commands)}  |  話者: {speaker or 'なし'}")

    def _animate_text(self):
        self._typing_job = None
        if not self.window.winfo_exists(): return
        self._typing_index = min(len(self._typing_text), self._typing_index + 1)
        if self._dialog_text_id is not None:
            try: self.canvas.itemconfigure(self._dialog_text_id, text=self._typing_text[:self._typing_index])
            except tk.TclError: pass
        if self._typing_index < len(self._typing_text):
            self._typing_job = self.window.after(self.display_settings["type_speed"], self._animate_text)

    def show_dialogue(self, text: str, speaker: str):
        self._cancel_typing()
        self._typing_text = text
        self._typing_speaker = speaker
        self._typing_index = 0
        if self.display_settings["typewriter"]:
            self.refresh_stage("", speaker)
            if text:
                self._typing_job = self.window.after(self.display_settings["type_speed"], self._animate_text)
        else:
            self._typing_index = len(text)
            self.refresh_stage(text, speaker)

    def _cancel_typing(self):
        if self._typing_job is not None:
            try: self.window.after_cancel(self._typing_job)
            except tk.TclError: pass
            self._typing_job = None


    def play_audio(self, command: str):
        if self.audio is None:
            return
        if command == "stop":
            self.audio.stop_bgm()
            return
        p = self.asset_path(command)
        if not p or p.suffix.lower() != ".wav":
            return
        try:
            if command == self.engine.bgm:
                self.audio.play_bgm(p, self.engine.bgm_volume)
            else:
                self.audio.play_se(p, self.engine.last_se_volume)
        except Exception:
            pass

    def sync_audio(self):
        if self.engine.bgm != self._last_bgm:
            if self.engine.bgm:
                self.play_audio(self.engine.bgm)
            else:
                self.play_audio("stop")
            self._last_bgm = self.engine.bgm
        if self.engine.last_se and self.engine.last_se != self._last_se:
            self.play_audio(self.engine.last_se)
            self._last_se = self.engine.last_se

    def step(self, choice_index: int | None = None):
        for child in self.choice_frame.winfo_children(): child.destroy()
        self.next_btn.configure(state="normal")
        try: event = self.engine.advance(choice_index)
        except Exception as exc:
            messagebox.showerror("実行エラー", str(exc), parent=self.window); self.close(); return
        self.sync_audio()
        if event["type"] == "text":
            self.show_dialogue(event["text"], event["speaker"])
            self.next_btn.configure(text="次へ ▶", state="normal")
        elif event["type"] == "choices":
            self._typing_text = "どちらを選びますか？"; self._typing_speaker = self.engine.speaker; self._typing_index = len(self._typing_text)
            self.refresh_stage(self._typing_text, self._typing_speaker)
            self.next_btn.configure(state="disabled")
            for i, (label, _target) in enumerate(event["choices"]):
                ttk.Button(self.choice_frame, text=label, command=lambda n=i: self.step(n)).pack(fill="x", pady=3)
        elif event["type"] == "wait":
            self._typing_text = ""; self._typing_speaker = self.engine.speaker; self._typing_index = 0
            self.refresh_stage("", self.engine.speaker)
            self.next_btn.configure(state="disabled")
            self.window.after(event["ms"], self.step)
        else:
            self._typing_text = "物語はここで終わります。プレイありがとうございました。"; self._typing_speaker = self.engine.speaker; self._typing_index = len(self._typing_text)
            self.refresh_stage(self._typing_text, self.engine.speaker)
            self.next_btn.configure(text="閉じる", command=self.close, state="normal")
            self.status.configure(text="ゲーム終了: " + (", ".join(sorted(self.engine.ending_flags)) or "end"))
            self.play_audio("stop")

    def next(self):
        if str(self.next_btn["state"]) == "disabled": return
        if self._typing_job is not None:
            self._cancel_typing()
            self._typing_index = len(self._typing_text)
            if self._dialog_text_id is not None:
                self.canvas.itemconfigure(self._dialog_text_id, text=self._typing_text)
            return
        if self.engine.ended: self.close()
        else: self.step()

    def close(self):
        self._cancel_typing()
        if self._resize_job is not None:
            try: self.window.after_cancel(self._resize_job)
            except tk.TclError: pass
        self.play_audio("stop")
        if self.audio is not None:
            try: self.audio.close()
            except Exception: pass
        try: self.window.destroy()
        except tk.TclError: pass


class NovelScriptApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{APP_NAME} {APP_VERSION}")
        self.root.geometry("1280x820")
        self.root.minsize(1000, 650)
        self.root.configure(bg="#171d29")
        self.current_file: Path | None = None
        self.base_dir = resource_path()
        self.modified = False
        self._refresh_job = None
        self._issues: list[tuple[str, int, str]] = []
        self.display_settings = load_display_settings()
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.quit)
        self.load_default_sample()

    def _build_ui(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("TFrame", background="#171d29")
        style.configure("Panel.TFrame", background="#202a3a")
        style.configure("TLabel", background="#171d29", foreground="#e8edf5", font=("Meiryo UI", 10))
        style.configure("Title.TLabel", font=("Meiryo UI", 18, "bold"), foreground="#ffffff")
        style.configure("Sub.TLabel", foreground="#9caec5")
        style.configure("TButton", padding=(10, 7), font=("Meiryo UI", 9))
        style.configure("Accent.TButton", background="#315f95", foreground="white")
        style.configure("Treeview", rowheight=27, font=("Meiryo UI", 9), background="#202a3a", fieldbackground="#202a3a", foreground="#e8edf5")
        style.configure("Treeview.Heading", font=("Meiryo UI", 9, "bold"))

        header = ttk.Frame(self.root, padding=(16, 12)); header.pack(fill="x")
        ttk.Label(header, text="NovelScript Engine", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="  v1.1 Desktop  |  Windowsネイティブ版・オフライン", style="Sub.TLabel").pack(side="left", padx=(8, 0), pady=(7, 0))
        toolbar = ttk.Frame(header); toolbar.pack(side="right")
        for label, fn in [("新規", self.new_file), ("開く", self.open_file), ("保存", self.save_file), ("別名保存", self.save_as), ("構文チェック", self.validate), ("文字表示設定", self.open_display_settings), ("▶ テストプレイ", self.play)]:
            ttk.Button(toolbar, text=label, command=fn, style="Accent.TButton" if label.startswith("▶") else "TButton").pack(side="left", padx=3)

        body = ttk.Panedwindow(self.root, orient="horizontal"); body.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        left = ttk.Frame(body, style="Panel.TFrame", padding=10); body.add(left, weight=1)
        center = ttk.Frame(body, style="Panel.TFrame", padding=10); body.add(center, weight=5)
        right = ttk.Frame(body, style="Panel.TFrame", padding=10); body.add(right, weight=1)

        ttk.Label(left, text="シーン / ラベル", font=("Meiryo UI", 11, "bold")).pack(anchor="w", pady=(2, 8))
        self.scene_list = tk.Listbox(left, bg="#202a3a", fg="#e8edf5", selectbackground="#315f95", relief="flat", font=("Meiryo UI", 10), activestyle="none")
        self.scene_list.pack(fill="both", expand=True)
        self.scene_list.bind("<<ListboxSelect>>", self.goto_scene)
        ttk.Button(left, text="先頭へ", command=lambda: self.editor.mark_set("insert", "1.0")).pack(fill="x", pady=(8, 0))
        ttk.Button(left, text="ラベル挿入", command=lambda: self.insert_text("\n*new_label\n")).pack(fill="x", pady=(5, 0))

        editor_top = ttk.Frame(center); editor_top.pack(fill="x")
        ttk.Label(editor_top, text="シナリオコード (.nse)", font=("Meiryo UI", 11, "bold")).pack(side="left")
        self.file_label = ttk.Label(editor_top, text="新規シナリオ", style="Sub.TLabel"); self.file_label.pack(side="right")
        editor_box = ttk.Frame(center); editor_box.pack(fill="both", expand=True, pady=(8, 8))
        self.line_numbers = tk.Text(editor_box, width=5, padx=6, takefocus=0, border=0, state="disabled", bg="#182231", fg="#71839a", font=("Consolas", 11), wrap="none")
        self.line_numbers.pack(side="left", fill="y")
        self.editor = tk.Text(editor_box, undo=True, maxundo=-1, wrap="none", bg="#101722", fg="#e6edf7", insertbackground="white", selectbackground="#315f95", font=("Consolas", 12), padx=10, pady=8, relief="flat", tabs=(32,))
        yscroll = ttk.Scrollbar(editor_box, orient="vertical", command=self._scroll_editor)
        xscroll = ttk.Scrollbar(center, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=lambda *a: (yscroll.set(*a), self._sync_lines()), xscrollcommand=xscroll.set)
        self.editor.pack(side="left", fill="both", expand=True); yscroll.pack(side="right", fill="y"); xscroll.pack(fill="x")
        self.editor.bind("<<Modified>>", self.on_modified)
        self.editor.bind("<KeyRelease>", self.schedule_refresh)
        self.editor.bind("<Control-s>", lambda e: self.save_file())
        self.editor.bind("<Control-Return>", lambda e: self.play())
        ttk.Label(center, text="構文チェック結果", font=("Meiryo UI", 10, "bold")).pack(anchor="w", pady=(4, 4))
        self.issue_list = tk.Listbox(center, height=6, bg="#202a3a", fg="#e8edf5", selectbackground="#315f95", relief="flat", font=("Meiryo UI", 9))
        self.issue_list.pack(fill="x")
        self.issue_list.bind("<Double-Button-1>", self.goto_issue)

        ttk.Label(right, text="命令入力支援", font=("Meiryo UI", 11, "bold")).pack(anchor="w", pady=(2, 8))
        ttk.Label(right, text="命令を選択して挿入できます。", style="Sub.TLabel", wraplength=205).pack(anchor="w", pady=(0, 8))
        for cmd, template in COMMANDS.items():
            ttk.Button(right, text=f"{cmd:<8} 挿入", command=lambda t=template: self.insert_text(t + "\n")).pack(fill="x", pady=2)
        ttk.Separator(right).pack(fill="x", pady=12)
        ttk.Label(right, text="キーボード操作", font=("Meiryo UI", 10, "bold")).pack(anchor="w")
        shortcuts = "Ctrl + S  保存\nCtrl + Enter  テストプレイ\nCtrl + Z  元に戻す\nCtrl + Y  やり直し\nダブルクリック  エラー行へ移動"
        ttk.Label(right, text=shortcuts, style="Sub.TLabel", justify="left").pack(anchor="w", pady=(6, 0))
        ttk.Separator(right).pack(fill="x", pady=12)
        ttk.Label(right, text="互換命令", font=("Meiryo UI", 10, "bold")).pack(anchor="w")
        ttk.Label(right, text="text / msg / name\nbg / chara / bgm / se\nwait / select / jump\nset / inc / if / endif\nendflag / clear / end", style="Sub.TLabel", justify="left").pack(anchor="w", pady=(6, 0))

        footer = ttk.Frame(self.root, padding=(12, 2, 12, 8)); footer.pack(fill="x")
        self.status = ttk.Label(footer, text="準備完了", style="Sub.TLabel"); self.status.pack(side="left")
        self.count_label = ttk.Label(footer, text="", style="Sub.TLabel"); self.count_label.pack(side="right")

    def open_display_settings(self):
        """Open the visual novel dialogue appearance editor."""
        win = tk.Toplevel(self.root)
        win.title("画面の文字表示設定")
        win.geometry("760x760")
        win.minsize(680, 660)
        win.transient(self.root)
        win.grab_set()

        draft = dict(self.display_settings)
        families = sorted(set(tkfont.families(self.root)), key=str.casefold)
        if draft["font_family"] not in families: families.insert(0, draft["font_family"])
        outer = ttk.Frame(win, padding=14); outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="ゲーム画面の文字・会話ウィンドウの見た目を変更します。", font=("Meiryo UI", 10, "bold")).pack(anchor="w", pady=(0, 10))
        body = ttk.Frame(outer); body.pack(fill="both", expand=True)
        left = ttk.Frame(body); left.pack(side="left", fill="both", expand=True, padx=(0, 12))
        right = ttk.LabelFrame(body, text="プレビュー", padding=8); right.pack(side="right", fill="y")

        vars: dict[str, Any] = {}
        color_buttons: dict[str, ttk.Button] = {}
        localized_values = {
            "layout": {"window":"会話ウィンドウ", "fullscreen":"全画面テキスト", "subtitle":"字幕スタイル"},
            "font_weight": {"normal":"標準", "bold":"太字"},
            "text_align": {"left":"左寄せ", "center":"中央揃え", "right":"右寄せ"},
            "panel_pattern": {"gray25":"薄く表示", "gray50":"半透明風", "gray75":"濃く表示", "":"不透明"},
            "panel_position": {"top":"上", "middle":"中央", "bottom":"下"},
        }
        def add_combo(parent, row, label, key, values, names=None):
            ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=5)
            v=tk.StringVar(value=draft[key]); vars[key]=v
            display_values=names or values
            cb=ttk.Combobox(parent, textvariable=v, values=display_values, state="readonly", width=24)
            cb.grid(row=row, column=1, sticky="ew", padx=(8,0), pady=5)
            if v.get() not in display_values: v.set(display_values[0])
            return cb
        def add_spin(parent,row,label,key,low,high):
            ttk.Label(parent,text=label).grid(row=row,column=0,sticky="w",pady=5)
            v=tk.IntVar(value=int(draft[key]));vars[key]=v
            ttk.Spinbox(parent,from_=low,to=high,textvariable=v,width=8).grid(row=row,column=1,sticky="w",padx=(8,0),pady=5)
        def add_check(parent,row,label,key):
            v=tk.BooleanVar(value=bool(draft[key]));vars[key]=v
            ttk.Checkbutton(parent,text=label,variable=v).grid(row=row,column=0,columnspan=2,sticky="w",pady=5)
        def color_button(parent,row,label,key):
            ttk.Label(parent,text=label).grid(row=row,column=0,sticky="w",pady=5)
            b=ttk.Button(parent,text=draft[key],command=lambda:pick_color(key,b))
            b.grid(row=row,column=1,sticky="ew",padx=(8,0),pady=5)
            color_buttons[key]=b
            vars[key]=draft[key]
        def pick_color(key,button):
            chosen=colorchooser.askcolor(color=str(vars[key]),parent=win,title="色を選択")
            if chosen and chosen[1]:
                vars[key]=chosen[1];button.configure(text=chosen[1]);update_preview()

        row=0
        add_combo(left,row,"表示レイアウト","layout",["window","fullscreen","subtitle"],["会話ウィンドウ","全画面テキスト","字幕スタイル"]);row+=1
        add_combo(left,row,"フォント","font_family",families);row+=1
        add_spin(left,row,"文字サイズ（pt）","font_size",10,48);row+=1
        add_combo(left,row,"文字の太さ","font_weight",["normal","bold"],["標準","太字"]);row+=1
        add_combo(left,row,"文字揃え","text_align",["left","center","right"],["左寄せ","中央揃え","右寄せ"]);row+=1
        color_button(left,row,"本文の文字色","text_color");row+=1
        color_button(left,row,"話者名の文字色","name_color");row+=1
        color_button(left,row,"ウィンドウ背景色","panel_color");row+=1
        color_button(left,row,"枠線の色","panel_border");row+=1
        add_combo(left,row,"背景の透過パターン","panel_pattern",["gray25","gray50","gray75",""],["薄く表示","半透明風","濃く表示","不透明"]);row+=1
        add_combo(left,row,"表示位置","panel_position",["top","middle","bottom"],["上","中央","下"]);row+=1
        add_spin(left,row,"ウィンドウ高さ（%）","panel_height",15,60);row+=1
        add_spin(left,row,"左右の余白（%）","side_margin",1,20);row+=1
        add_check(left,row,"文字を1文字ずつ表示する（タイプライター）","typewriter");row+=1
        add_spin(left,row,"1文字ごとの時間（ミリ秒）","type_speed",10,200);row+=1
        left.columnconfigure(1,weight=1)

        preview=tk.Canvas(right,width=270,height=230,bg="#202938",highlightthickness=0)
        preview.pack(fill="both",expand=True)
        def collect():
            values={}
            for key,v in vars.items():
                try:
                    values[key] = v.get() if isinstance(v, tk.Variable) else v
                except tk.TclError:
                    values[key] = DEFAULT_DISPLAY_SETTINGS[key]
            # Translate localized combo labels back to internal values.
            for key, mapping in (("layout",{"会話ウィンドウ":"window","全画面テキスト":"fullscreen","字幕スタイル":"subtitle"}),
                                 ("font_weight",{"標準":"normal","太字":"bold"}),
                                 ("text_align",{"左寄せ":"left","中央揃え":"center","右寄せ":"right"}),
                                 ("panel_pattern",{"薄く表示":"gray25","半透明風":"gray50","濃く表示":"gray75","不透明":""}),
                                 ("panel_position",{"上":"top","中央":"middle","下":"bottom"})):
                if values.get(key) in mapping: values[key]=mapping[values[key]]
            return normalize_display_settings(values)
        def update_preview(*_):
            cfg=collect();preview.delete("all")
            pw,ph=270,230
            preview.create_rectangle(0,0,pw,ph,fill="#26364a",outline="")
            if cfg["layout"]=="fullscreen": top,bottom=12,ph-12
            else:
                hh=int(ph*cfg["panel_height"]/100)
                top=12 if cfg["panel_position"]=="top" else (ph-hh)//2 if cfg["panel_position"]=="middle" else ph-hh-12
                bottom=top+hh
            preview.create_rectangle(8,top,pw-8,bottom,fill=cfg["panel_color"],outline=cfg["panel_border"],width=2,stipple=cfg["panel_pattern"] or "")
            x={"left":20,"center":pw//2,"right":pw-20}[cfg["text_align"]]
            anchor={"left":"nw","center":"n","right":"ne"}[cfg["text_align"]]
            name_y=top+8;text_y=top+43
            preview.create_text(20,name_y,text="主人公",anchor="nw",fill=cfg["name_color"],font=(cfg["font_family"],max(8,cfg["font_size"]-3),"bold"))
            preview.create_text(x,text_y,text="表示スタイルを\nここで確認できます。",anchor=anchor,width=pw-42,justify=cfg["text_align"],fill=cfg["text_color"],font=(cfg["font_family"],max(8,min(cfg["font_size"],26)),cfg["font_weight"]))
        for v in vars.values():
            if hasattr(v,"trace_add"): v.trace_add("write",update_preview)
        ttk.Label(right,text="設定変更に合わせてプレビューします。",wraplength=250).pack(anchor="w",pady=(8,0))
        update_preview()

        buttons=ttk.Frame(outer);buttons.pack(fill="x",pady=(12,0))
        def apply(close=False):
            self.display_settings=collect()
            try: save_display_settings(self.display_settings)
            except OSError as exc:
                messagebox.showerror("設定保存エラー",f"表示設定を保存できませんでした。\n{exc}",parent=win);return
            self.status.configure(text="画面の文字表示設定を保存しました")
            if close: win.destroy()
        def reset():
            for key,v in vars.items():
                base=DEFAULT_DISPLAY_SETTINGS[key]
                if isinstance(v,tk.Variable):
                    v.set(localized_values.get(key, {}).get(base, base))
                else:
                    vars[key]=base
                    if key in color_buttons: color_buttons[key].configure(text=base)
            update_preview()
        ttk.Button(buttons,text="初期設定に戻す",command=reset).pack(side="left")
        ttk.Button(buttons,text="適用",command=lambda:apply(False)).pack(side="right",padx=(6,0))
        ttk.Button(buttons,text="保存して閉じる",command=lambda:apply(True)).pack(side="right")
        ttk.Button(buttons,text="閉じる",command=win.destroy).pack(side="right",padx=(0,6))

    def _scroll_editor(self, *args):
        self.editor.yview(*args); self._sync_lines()

    def _sync_lines(self):
        if not hasattr(self, "editor"): return
        last = int(self.editor.index("end-1c").split(".")[0])
        nums = "\n".join(str(i) for i in range(1, last + 1))
        self.line_numbers.configure(state="normal"); self.line_numbers.delete("1.0", "end"); self.line_numbers.insert("1.0", nums); self.line_numbers.configure(state="disabled")
        self.line_numbers.yview_moveto(self.editor.yview()[0])
        self.count_label.configure(text=f"{last} 行")

    def get_source(self) -> str:
        return self.editor.get("1.0", "end-1c")

    def set_source(self, source: str):
        self.editor.delete("1.0", "end"); self.editor.insert("1.0", source)
        self.editor.edit_modified(False); self.modified = False; self._sync_lines(); self.update_scenes()

    def load_default_sample(self):
        demo = resource_path("examples", "sample_5min.nse")
        if demo.exists():
            # Bundled sample lives in PyInstaller's temporary extraction directory.
            # Never overwrite it; the first Save must ask the user for a writable path.
            self.current_file = None; self.base_dir = resource_path()
            self.set_source(demo.read_text(encoding="utf-8")); self.file_label.configure(text=demo.name + "（サンプル）")
            self.status.configure(text="5分テストシナリオを読み込みました（サンプル・未保存）")
        else:
            self.set_source("; NovelScript Engine\n*start\nname \"主人公\"\ntext \"こんにちは。\"\nend\n")

    def on_modified(self, _event=None):
        if self.editor.edit_modified():
            self.modified = True
            self.editor.edit_modified(False)
            self._sync_lines()

    def schedule_refresh(self, _event=None):
        if self._refresh_job: self.root.after_cancel(self._refresh_job)
        self._refresh_job = self.root.after(450, self.update_scenes)

    def update_scenes(self):
        self._refresh_job = None
        keep = self.scene_list.curselection()
        self.scene_list.delete(0, "end")
        for i, line in enumerate(self.get_source().splitlines(), 1):
            if line.strip().startswith("*"):
                self.scene_list.insert("end", f"{line.strip()[1:]}   ({i})")
        self._sync_lines()

    def goto_scene(self, _event=None):
        sel = self.scene_list.curselection()
        if not sel: return
        label = self.scene_list.get(sel[0]).split("   (")[0]
        for i, line in enumerate(self.get_source().splitlines(), 1):
            if line.strip() == "*" + label:
                self.editor.mark_set("insert", f"{i}.0"); self.editor.see(f"{i}.0"); self.editor.focus_set(); return

    def goto_issue(self, _event=None):
        sel = self.issue_list.curselection()
        if not sel: return
        idx = sel[0]
        if idx < len(self._issues):
            line = self._issues[idx][1]
            self.editor.mark_set("insert", f"{line}.0"); self.editor.see(f"{line}.0"); self.editor.focus_set()

    def insert_text(self, text: str):
        self.editor.insert("insert", text); self.editor.focus_set(); self.schedule_refresh()

    def new_file(self):
        if not self.confirm_discard(): return
        self.current_file = None; self.base_dir = Path.cwd()
        self.set_source("; 新しいNovelScriptシナリオ\n*start\nname \"主人公\"\ntext \"ここに文章を入力します。\"\nend\n")
        self.file_label.configure(text="新規シナリオ"); self.status.configure(text="新しいシナリオ")

    def confirm_discard(self) -> bool:
        if not self.modified: return True
        return messagebox.askyesno("未保存の変更", "変更が保存されていません。破棄して続行しますか？", parent=self.root)

    def open_file(self):
        if not self.confirm_discard(): return
        path = filedialog.askopenfilename(parent=self.root, title="シナリオを開く", filetypes=[("NovelScript / Project", "*.nse *.txt *.nproj"), ("すべてのファイル", "*.*")])
        if not path: return
        p = Path(path)
        try:
            if p.suffix.lower() == ".nproj":
                data = json.loads(p.read_text(encoding="utf-8-sig")); src = project_to_nse(data)
                self.current_file = p; self.base_dir = p.parent
                self.file_label.configure(text=f"{p.name}（プロジェクト）")
            else:
                src = p.read_text(encoding="utf-8-sig"); self.current_file = p; self.base_dir = p.parent
                self.file_label.configure(text=p.name)
            self.set_source(src); self.status.configure(text=f"読み込み: {p.name}")
            self.validate()
        except Exception as exc:
            messagebox.showerror("読み込みエラー", str(exc), parent=self.root)

    def save_file(self):
        if self.current_file is None: return self.save_as()
        try:
            if self.current_file.suffix.lower() == ".nproj":
                data = nse_to_project(self.get_source(), self.current_file.stem)
                self.current_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            else:
                self.current_file.write_text(self.get_source(), encoding="utf-8-sig")
            self.base_dir = self.current_file.parent; self.modified = False
            self.status.configure(text=f"保存しました: {self.current_file.name}")
            return True
        except Exception as exc:
            messagebox.showerror("保存エラー", str(exc), parent=self.root); return False

    def save_as(self):
        path = filedialog.asksaveasfilename(parent=self.root, title="シナリオを保存", defaultextension=".nse", filetypes=[("NovelScript", "*.nse"), ("NovelScript Project", "*.nproj"), ("テキスト", "*.txt")])
        if not path: return False
        self.current_file = Path(path); self.base_dir = self.current_file.parent
        self.file_label.configure(text=self.current_file.name); return self.save_file()

    def validate(self):
        self._issues = validate_script(self.get_source())
        self.issue_list.delete(0, "end")
        for level, line, msg in self._issues:
            mark = "✖" if level == "エラー" else "!"
            self.issue_list.insert("end", f"{mark} {level}  {line}行目: {msg}")
        errors = sum(1 for x in self._issues if x[0] == "エラー")
        warnings = len(self._issues) - errors
        if not self._issues: self.issue_list.insert("end", "✓ エラー・警告はありません")
        self.status.configure(text=f"構文チェック: エラー {errors} 件 / 警告 {warnings} 件")
        if errors == 0:
            messagebox.showinfo("構文チェック", f"構文チェック完了\nエラー: 0 件\n警告: {warnings} 件", parent=self.root)
        else:
            messagebox.showwarning("構文チェック", f"エラーが {errors} 件あります。結果一覧を確認してください。", parent=self.root)
        return errors == 0

    def play(self):
        source = self.get_source()
        issues = validate_script(source)
        errors = [x for x in issues if x[0] == "エラー"]
        if errors:
            self._issues = issues; self.issue_list.delete(0, "end")
            for level, line, msg in issues: self.issue_list.insert("end", f"{level}  {line}行目: {msg}")
            messagebox.showwarning("テストプレイを開始できません", f"構文エラーが {len(errors)} 件あります。先に修正してください。", parent=self.root); return
        NativePlayer(self, source, self.base_dir)

    def quit(self):
        if self.confirm_discard(): self.root.destroy()


def main():
    root = tk.Tk()
    try:
        app = NovelScriptApp(root)
        root.mainloop()
    except Exception as exc:
        messagebox.showerror(APP_NAME, str(exc))
        raise

if __name__ == "__main__":
    main()
