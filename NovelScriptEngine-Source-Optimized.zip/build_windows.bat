@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ================================================
echo NovelScript Engine v1.0 - Windows EXE Builder
echo ================================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher (py) が見つかりません。
  echo Python 3.12以降をインストールしてください。
  pause
  exit /b 1
)
echo [1/4] Build用の仮想環境を準備します...
if not exist ".build-venv\Scripts\python.exe" (
  py -3.12 -m venv .build-venv
  if errorlevel 1 (
    echo Python 3.12 が見つかりません。Python 3.12をインストールしてください。
    pause
    exit /b 1
  )
)
set "PY=.build-venv\Scripts\python.exe"
echo [2/4] PyInstallerを確認・インストールします...
"%PY%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%PY%" -m pip install -r requirements-build.txt
if errorlevel 1 goto :error
echo [3/4] Windows GUI EXEをビルドします...
"%PY%" -m PyInstaller --noconfirm --clean --windowed --onefile --name NovelScriptEngine --add-data "assets;assets" --add-data "assets_png;assets_png" --add-data "examples;examples" app.py
if errorlevel 1 goto :error
echo [4/4] EXEをreleaseフォルダへコピーします...
if not exist release mkdir release
copy /Y "dist\NovelScriptEngine.exe" "release\NovelScriptEngine.exe" >nul
if errorlevel 1 goto :error
echo.
echo ================================================
echo ビルド完了: release\NovelScriptEngine.exe
echo このEXEはPythonやネット接続なしで起動できます。
echo ================================================
start "" explorer "%~dp0release"
pause
exit /b 0
:error
echo.
echo ビルドに失敗しました。上のエラーメッセージを確認してください。
pause
exit /b 1
