; 雨宿りの駅と青い手紙 / 約5分テストプレイ
; Original sample assets are in ./assets and described in ASSET_CREDITS.md
*start
bg "assets/bg_station.svg"
bgm "assets/bgm_station.wav" 42
se "assets/ambience_rain.wav" 12
chara "mio" "assets/mio_neutral.svg" center
name "主人公"
text "終電が出てから、もう十分は経った。駅の時計は午後十一時を少し回り、雨はホームの屋根を細かく叩いている。"
text "帰る理由なら、いくらでもあった。それでも僕は、濡れたベンチの端に座り続けていた。"
se "assets/se_station_chime.wav" 52
name "美緒"
text "……まだ、いたんだ。"
chara "mio" "assets/mio_worried.svg" center
text "声のした方を見ると、昼間にこの駅で会った美緒が立っていた。制服の袖を握り、少し困ったように笑っている。"
name "主人公"
text "傘、忘れたの？"
name "美緒"
text "ううん。持ってる。でも、帰りたくなくて。変だよね。"
text "彼女の手には、青い封筒があった。角は雨に濡れ、宛名の文字が少しだけ滲んでいる。"
text "美緒は封筒を見つめたまま、何かを言いかけてやめた。僕は急かさず、雨音を聞いていた。"
select "どうしたのか、静かに尋ねる" talk_route
select "何も言わず、傘を差し出す" silent_route
*talk_route
set route 1
name "主人公"
text "話したくなったら聞くよ。うまく話せなくてもいい。"
name "美緒"
chara "mio" "assets/mio_smile.svg" center
text "ありがとう。そう言ってもらえるだけで、少し息がしやすくなる。"
text "美緒は青い封筒を胸に抱いた。中には、遠くへ引っ越した友人から届いた最後の手紙が入っているらしい。"
text "返事を書けないまま、季節だけが過ぎてしまった。今夜、この駅で会う約束をしていたのだという。"
jump riverside
*silent_route
set route 0
name "主人公"
text "僕は言葉の代わりに、傘を彼女の方へ傾けた。肩が濡れるのは、今は気にならなかった。"
name "美緒"
chara "mio" "assets/mio_smile.svg" center
text "ふふ。あなたって、そういうところがあるよね。"
text "美緒は青い封筒を見つめた。遠くへ引っ越した友人に返事を書けず、今夜ここで会う約束だけを頼りにしていたらしい。"
text "電車はもうない。けれど、彼女はすぐに帰ろうとはしなかった。"
jump riverside
*riverside
bg "assets/bg_riverside.svg"
bgm "assets/bgm_memory.wav" 48
se "assets/se_footsteps.wav" 30
name "主人公"
text "駅から川沿いの道へ出た。雨は細くなり、街灯が水面に長い線を描いている。"
text "橋の向こうには、昔ふたりでよく歩いた小さな公園がある。美緒はそこで手紙を渡すつもりだった。"
name "美緒"
chara "mio" "assets/mio_neutral.svg" center
text "あの子は、いつも先に歩いていく人だった。私は追いかけるばかりで、ありがとうも、ごめんねも、ちゃんと言えなかった。"
text "青い封筒の裏には、短い言葉が書かれていた。『雨の日、いつもの場所で』。それだけだった。"
text "もし会えなかったら、この手紙を読んでほしい。そう言われていたのに、美緒はまだ封を切れずにいた。"
select "ここで手紙を開いてみよう" open_letter
select "約束の公園まで一緒に歩こう" promise
*open_letter
if route == 1 jump letter_talk
jump letter_silent
*letter_talk
name "主人公"
text "一緒に読もう。最後まで読んだら、返事の言葉も見つかるかもしれない。"
name "美緒"
chara "mio" "assets/mio_worried.svg" center
text "封を切る音は、雨上がりの夜に小さく響いた。便箋には、懐かしい丸い文字が並んでいた。"
text "『あの日、駅で待っていてくれてありがとう。あなたと過ごした時間は、離れていても私の帰る場所です』。"
text "美緒の目から涙がこぼれた。でも、その顔にはもう迷いだけではない、やわらかな光があった。"
jump true_end
*letter_silent
name "美緒"
text "手紙を開くと、最初の一行に『傘を半分こした日のこと、覚えてる？』と書いてあった。"
text "続きには、ふたりで笑ったこと、喧嘩したこと、そして離れていても友だちでいたいという願いが綴られていた。"
text "私は返事をしなかったんじゃない。返事をするのが怖かったんだね。"
text "美緒は便箋をたたみ、胸元にしまった。今度こそ、自分の言葉で返事を書くと決めた。"
jump quiet_end
*promise
if route == 1 jump promise_talk
jump promise_silent
*promise_talk
bg "assets/bg_shrine.svg"
name "美緒"
chara "mio" "assets/mio_smile.svg" center
text "公園の先にある小さな社まで歩くと、雨雲の切れ間から朝の光が差し始めた。"
text "待ち合わせの相手は来なかった。それでも美緒は、ここまで来られたことを少し誇らしく思った。"
text "主人公、聞いてくれてありがとう。今度は私から手紙を書いてみる。届くかどうかより、伝えたいから。"
jump true_end
*promise_silent
bg "assets/bg_shrine.svg"
name "美緒"
chara "mio" "assets/mio_smile.svg" center
text "公園の先にある小さな社まで歩くと、雨雲の切れ間から朝の光が差し始めた。"
text "ふたりは長いあいだ、何も話さなかった。けれど沈黙は、さっきまでよりずっと優しいものに変わっていた。"
text "傘を返すね。今度は私が、誰かの雨宿りになれるようにする。"
jump quiet_end
*true_end
bg "assets/bg_shrine.svg"
name "美緒"
chara "mio" "assets/mio_smile.svg" center
text "朝のホームには、始発を待つ人たちが集まり始めていた。美緒は青い封筒を鞄にしまい、まっすぐ前を向いた。"
text "また会えるかどうかは、まだわからない。それでも、伝えたい言葉を見つけた人の歩幅は、昨日より少しだけ軽い。"
name "主人公"
text "雨は上がった。僕たちは同じ電車に乗り、窓の向こうに流れる朝の街を眺めた。"
endflag true_end
end
*quiet_end
bg "assets/bg_shrine.svg"
name "美緒"
chara "mio" "assets/mio_neutral.svg" center
text "朝のホームには、始発を待つ人たちが集まり始めていた。美緒は青い封筒を鞄にしまい、そっと息を吐いた。"
text "返事は、今日書こう。きれいな言葉じゃなくても、自分の声で。そう決めたら、胸の奥の雨雲が少し晴れた気がした。"
name "主人公"
text "言葉にできない夜があってもいい。次の朝に、もう一度始めればいい。"
text "駅の時計が、午前五時を告げた。美緒は小さく手を振り、始発のドアへ歩いていった。"
endflag quiet_end
end
