import json, sys, tkinter as tk
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import NovelScriptApp, NativePlayer, project_to_nse
root=tk.Tk(); app=NovelScriptApp(root)
root.update_idletasks(); root.update()
assert len(app.get_source().splitlines()) > 100
assert not [x for x in app._issues if x[0]=='エラー']
# Validate that .nproj import follows same path as GUI open.
p=json.loads((ROOT/'examples/testplay_5min.nproj').read_text(encoding='utf-8'))
src=project_to_nse(p)
player=NativePlayer(app,src,ROOT/'examples')
root.update_idletasks(); root.update()
# Move the runtime state to each choice and exercise a route; the GUI's choice buttons are created too.
e=player.engine
x=e.advance()
while x['type']!='choices': x=e.advance()
assert len(x['choices'])==2
x=e.advance(0)
while x['type']!='choices': x=e.advance()
x=e.advance(0)
while x['type']!='end':
    x=e.advance(0) if x['type']=='choices' else e.advance()
assert 'true_end' in e.ending_flags
player.close(); root.destroy()
print('GUI smoke passed: app window, embedded demo, runtime window, choices, TRUE END')
