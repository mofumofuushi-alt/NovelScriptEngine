import json, sys, tkinter as tk
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import NovelScriptApp, NativePlayer, project_to_nse

root=tk.Tk(); app=NovelScriptApp(root)
root.update_idletasks(); root.update()
assert len(app.get_source().splitlines()) > 100
assert not [x for x in app._issues if x[0]=='エラー']
p=json.loads((ROOT/'examples/testplay_5min.nproj').read_text(encoding='utf-8'))
src=project_to_nse(p)
player=NativePlayer(app,src,ROOT/'examples')
root.update_idletasks(); root.update()
# Advance through the first route until the runtime presents its choice overlay.
for _ in range(120):
    if player.current_choices:
        break
    player.step()
    root.update_idletasks(); root.update()
assert len(player.current_choices)==2, f'expected 2 screen choices, got {player.current_choices!r}'
assert not hasattr(player, 'choice_frame'), 'choices should no longer be placed below the game canvas'
choice_items=player.canvas.find_withtag('choice')
assert len(choice_items)>=4, f'expected canvas choice backgrounds and labels, got {choice_items!r}'
bbox=player.canvas.bbox('choice')
assert bbox is not None and bbox[1]>=0 and bbox[3]<=player.canvas.winfo_height()+2, f'choice overlay outside game view: {bbox}'
# Stress the overlay with a small dialogue panel, large configured font and longer choices.
original_settings=dict(player.display_settings)
long_choices=[(f'長い選択肢の表示テスト {n}：物語の展開を選んで次の場面へ進みます。', f'target_{n}') for n in range(6)]
for layout, position in (('window','top'),('fullscreen','middle'),('subtitle','bottom')):
    player.display_settings={**original_settings,'layout':layout,'panel_position':position,'panel_height':15,'font_size':48}
    player.refresh_stage('どちらを選びますか？','美緒',long_choices)
    root.update_idletasks(); root.update()
    many_bbox=player.canvas.bbox('choice')
    assert many_bbox is not None and many_bbox[1]>=0 and many_bbox[3]<=player.canvas.winfo_height()+2, f'{layout}/{position} choice overlay clipped: {many_bbox}'
player.display_settings=original_settings
player.refresh_stage('どちらを選びますか？',player._typing_speaker,player.current_choices)
root.update_idletasks(); root.update()
# Click-equivalent selection still follows the same script branch.
player.choose(0)
for _ in range(300):
    if player.engine.ended:
        break
    if player.current_choices:
        player.choose(0)
    else:
        player.step()
    root.update_idletasks(); root.update()
assert 'true_end' in player.engine.ending_flags, f'unexpected endings: {player.engine.ending_flags}'
player.close(); root.destroy()
print('GUI smoke passed: editor, game canvas choice overlay, in-screen bounds, selection and TRUE END')
