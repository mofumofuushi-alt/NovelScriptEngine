import json, sys, tkinter as tk
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import NovelScriptApp, NativePlayer, project_to_nse, normalize_display_settings

root=tk.Tk(); app=NovelScriptApp(root)
root.update_idletasks(); root.update()
assert len(app.get_source().splitlines()) > 100
assert not [x for x in app._issues if x[0]=='エラー']
p=json.loads((ROOT/'examples/testplay_5min.nproj').read_text(encoding='utf-8'))
src=project_to_nse(p)
player=NativePlayer(app,src,ROOT/'examples')
root.update_idletasks(); root.update()
# Advance through the first route until the runtime presents its choice overlay.
for _ in range(120):
    if player.current_choices:
        break
    player.step()
    root.update_idletasks(); root.update()
assert len(player.current_choices)==2, f'expected 2 screen choices, got {player.current_choices!r}'
assert not hasattr(player, 'choice_frame'), 'choices should no longer be placed below the game canvas'
choice_items=player.canvas.find_withtag('choice')
assert len(choice_items)>=4, f'expected canvas choice backgrounds and labels, got {choice_items!r}'
bbox=player.canvas.bbox('choice')
assert bbox is not None and bbox[1]>=0 and bbox[3]<=player.canvas.winfo_height()+2, f'choice overlay outside game view: {bbox}'
# Stress the overlay with a small dialogue panel, large configured font and longer choices.
original_settings=dict(player.display_settings)
long_choices=[(f'長い選択肢の表示テスト {n}：物語の展開を選んで次の場面へ進みます。', f'target_{n}') for n in range(6)]
for layout, position in (('window','top'),('fullscreen','middle'),('subtitle','bottom')):
    player.display_settings={**original_settings,'layout':layout,'panel_position':position,'panel_height':15,'font_size':48}
    player.refresh_stage('どちらを選びますか？','美緒',long_choices)
    root.update_idletasks(); root.update()
    many_bbox=player.canvas.bbox('choice')
    assert many_bbox is not None and many_bbox[1]>=0 and many_bbox[3]<=player.canvas.winfo_height()+2, f'{layout}/{position} choice overlay clipped: {many_bbox}'
player.display_settings=original_settings
player.refresh_stage('どちらを選びますか？',player._typing_speaker,player.current_choices)
root.update_idletasks(); root.update()
# Click an actual choice card. It must not bubble into the canvas advance handler.
choice_bbox=player.canvas.bbox('choice-0')
assert choice_bbox is not None
pc_before=player.engine.pc
player.canvas.event_generate('<Button-1>', x=(choice_bbox[0]+choice_bbox[2])//2, y=(choice_bbox[1]+choice_bbox[3])//2)
root.update_idletasks(); root.update()
assert player.engine.pc > pc_before and not player.current_choices
assert not player.engine.ended, 'choice click bubbled and advanced past the selected route dialogue'
# Continue to the TRUE END route without changing the existing select semantics.
for _ in range(300):
    if player.engine.ended:
        break
    if player.current_choices:
        player.choose(0)
    else:
        player.step()
    root.update_idletasks(); root.update()
assert 'true_end' in player.engine.ending_flags, f'unexpected endings: {player.engine.ending_flags}'
player.close()

# Test click-to-advance, including conventional two-stage typewriter behavior:
# first click completes the current line; following click advances to the next.
app.display_settings = normalize_display_settings({**app.display_settings,'typewriter':True,'type_speed':200})
click_script = '*start\ntext "一行目の文章"\ntext "二行目の文章"\nselect "Aルートへ進む" route_a\nselect "Bルートへ進む" route_b\n*route_a\ntext "Aルートに入りました"\nend\n*route_b\ntext "Bルートに入りました"\nend\n'
click_player=NativePlayer(app,click_script,ROOT)
root.update_idletasks(); root.update()
assert click_player._typing_text == '一行目の文章'
assert click_player._typing_job is not None, 'typewriter should still be animating before the first click'
first_pc=click_player.engine.pc
click_player.canvas.event_generate('<Button-1>',x=25,y=25)
root.update_idletasks(); root.update()
assert click_player._typing_index == len('一行目の文章'), 'first click should reveal the full current line'
assert click_player.engine.pc == first_pc, 'first click during typewriter should not advance to another command'
click_player.canvas.event_generate('<Button-1>',x=25,y=25)
root.update_idletasks(); root.update()
assert click_player._typing_text == '二行目の文章', 'second click should advance to the next line'
click_player.canvas.event_generate('<Button-1>',x=25,y=25)  # finish line
root.update_idletasks(); root.update()
click_player.canvas.event_generate('<Button-1>',x=25,y=25)  # show choices
root.update_idletasks(); root.update()
assert len(click_player.current_choices)==2, 'clicking the stage while choices are visible must not auto-select or advance'
click_player.close(); root.destroy()
print('GUI smoke passed: editor, in-screen choice overlay, safe choice click, click-to-advance and typewriter completion')
