import json, os, sys, tempfile, tkinter as tk
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import NovelScriptApp, NativePlayer, project_to_nse, normalize_display_settings, save_slot_image_path

root=tk.Tk(); app=NovelScriptApp(root)
root.update_idletasks(); root.update()
assert len(app.get_source().splitlines()) > 100
assert not [x for x in app._issues if x[0]=='エラー']
p=json.loads((ROOT/'examples/testplay_5min.nproj').read_text(encoding='utf-8'))
src=project_to_nse(p)
player=NativePlayer(app,src,ROOT/'examples')
root.update_idletasks(); root.update()
# Advance through the first route until the runtime presents its choice overlay.
for _ in range(120):
    if player.current_choices:
        break
    player.step()
    root.update_idletasks(); root.update()
assert len(player.current_choices)==2, f'expected 2 screen choices, got {player.current_choices!r}'
assert not hasattr(player, 'choice_frame'), 'choices should no longer be placed below the game canvas'
choice_items=player.canvas.find_withtag('choice')
assert len(choice_items)>=4, f'expected canvas choice backgrounds and labels, got {choice_items!r}'
bbox=player.canvas.bbox('choice')
assert bbox is not None and bbox[1]>=0 and bbox[3]<=player.canvas.winfo_height()+2, f'choice overlay outside game view: {bbox}'
# Stress the overlay with a small dialogue panel, large configured font and longer choices.
original_settings=dict(player.display_settings)
long_choices=[(f'長い選択肢の表示テスト {n}：物語の展開を選んで次の場面へ進みます。', f'target_{n}') for n in range(6)]
for layout, position in (('window','top'),('fullscreen','middle'),('subtitle','bottom')):
    player.display_settings={**original_settings,'layout':layout,'panel_position':position,'panel_height':15,'font_size':48}
    player.refresh_stage('どちらを選びますか？','美緒',long_choices)
    root.update_idletasks(); root.update()
    many_bbox=player.canvas.bbox('choice')
    assert many_bbox is not None and many_bbox[1]>=0 and many_bbox[3]<=player.canvas.winfo_height()+2, f'{layout}/{position} choice overlay clipped: {many_bbox}'
player.display_settings=original_settings
player.refresh_stage('どちらを選びますか？',player._typing_speaker,player.current_choices)
root.update_idletasks(); root.update()
# Click an actual choice card. It must not bubble into the canvas advance handler.
choice_bbox=player.canvas.bbox('choice-0')
assert choice_bbox is not None
pc_before=player.engine.pc
player.canvas.event_generate('<Button-1>', x=(choice_bbox[0]+choice_bbox[2])//2, y=(choice_bbox[1]+choice_bbox[3])//2)
root.update_idletasks(); root.update()
assert player.engine.pc > pc_before and not player.current_choices
assert not player.engine.ended, 'choice click bubbled and advanced past the selected route dialogue'
# Continue to the TRUE END route without changing the existing select semantics.
for _ in range(300):
    if player.engine.ended:
        break
    if player.current_choices:
        player.choose(0)
    else:
        player.step()
    root.update_idletasks(); root.update()
assert 'true_end' in player.engine.ending_flags, f'unexpected endings: {player.engine.ending_flags}'
player.close()

# Test click-to-advance, including conventional two-stage typewriter behavior:
# first click completes the current line; following click advances to the next.
app.display_settings = normalize_display_settings({**app.display_settings,'typewriter':True,'type_speed':200})
click_script = '*start\ntext "一行目の文章"\ntext "二行目の文章"\nselect "Aルートへ進む" route_a\nselect "Bルートへ進む" route_b\n*route_a\ntext "Aルートに入りました"\nend\n*route_b\ntext "Bルートに入りました"\nend\n'
click_player=NativePlayer(app,click_script,ROOT)
root.update_idletasks(); root.update()
assert click_player._typing_text == '一行目の文章'
assert click_player._typing_job is not None, 'typewriter should still be animating before the first click'
first_pc=click_player.engine.pc
click_player.canvas.event_generate('<Button-1>',x=25,y=25)
root.update_idletasks(); root.update()
assert click_player._typing_index == len('一行目の文章'), 'first click should reveal the full current line'
assert click_player.engine.pc == first_pc, 'first click during typewriter should not advance to another command'
click_player.canvas.event_generate('<Button-1>',x=25,y=25)
root.update_idletasks(); root.update()
assert click_player._typing_text == '二行目の文章', 'second click should advance to the next line'
click_player.canvas.event_generate('<Button-1>',x=25,y=25)  # finish line
root.update_idletasks(); root.update()
click_player.canvas.event_generate('<Button-1>',x=25,y=25)  # show choices
root.update_idletasks(); root.update()
assert len(click_player.current_choices)==2, 'clicking the stage while choices are visible must not auto-select or advance'

# Character sprites can be dragged to arbitrary screen positions without advancing dialogue.
char_script='*start\nchara "mio" "assets/mio_neutral.svg" 50 77\ntext "立ち絵を移動"\ntext "移動後も維持"\nend\n'
char_player=NativePlayer(app,char_script,ROOT)
root.update_idletasks(); root.update()
sprite=char_player.canvas.find_withtag('character-sprite')
assert sprite, 'character sprite should be drawn with a draggable tag'
start=char_player.canvas.coords(sprite[0])
char_player.canvas.event_generate('<Button-1>',x=int(start[0]),y=int(start[1]))
char_player.canvas.event_generate('<B1-Motion>',x=int(start[0]-100),y=int(start[1]-70))
char_player.canvas.event_generate('<ButtonRelease-1>',x=int(start[0]-100),y=int(start[1]-70))
root.update_idletasks(); root.update()
assert char_player.engine.character_x < 50 and char_player.engine.character_y < 77
saved_xy=(char_player.engine.character_x,char_player.engine.character_y)
char_player.refresh_stage(char_player._typing_text,char_player._typing_speaker,[])
root.update_idletasks(); root.update()
assert char_player.engine.character_x == saved_xy[0] and char_player.engine.character_y == saved_xy[1]
char_player.close()

# Right-click opens the in-game system menu with save/load and backlog entries.
# Avoid a platform-specific modal menu event loop during automation; the real
# Menu is still constructed and its labels are inspected on Windows and X11.
with patch.object(tk.Menu, 'tk_popup', lambda self, x, y: None):
    click_player.canvas.event_generate('<Button-3>', x=30, y=30)
    root.update_idletasks(); root.update()
assert click_player._context_menu is not None
assert click_player._context_menu.entrycget(0, 'label') == 'セーブ・ロード'
assert click_player._context_menu.entrycget(1, 'label') == 'バックログ'
click_player._context_menu.unpost(); root.update_idletasks(); root.update()

# Ten-slot save/load preserves exact interpreter state, pending choices and backlog.
with tempfile.TemporaryDirectory() as data_dir:
    with patch.dict(os.environ, {'XDG_DATA_HOME': data_dir, 'APPDATA': data_dir}):
        saved_pc = click_player.engine.pc
        saved_backlog = list(click_player.backlog)
        assert click_player.save_slot(1)
        record = click_player.read_slot(1)
        assert record is not None and record['snapshot']['state'] == 'choices'
        preview_path = save_slot_image_path(click_player.scenario_id, 1)
        if sys.platform != 'win32':
            assert preview_path.is_file(), 'Xvfb should provide a capturable game-screen PNG preview'
        if preview_path.is_file():
            from PIL import Image
            with Image.open(preview_path) as preview:
                assert preview.format == 'PNG' and preview.width <= 480 and preview.height <= 270
        assert record['snapshot']['engine']['waiting_choices'] is not None
        # Recreate a fresh player window from disk data, as after closing/relaunching a game.
        resumed_player = NativePlayer(app, click_script, ROOT, initial_state=record['snapshot'])
        root.update_idletasks(); root.update()
        assert len(resumed_player.current_choices) == 2
        assert resumed_player.engine.pc == saved_pc
        resumed_player.close()
        click_player.choose(0)
        assert not click_player.current_choices
        assert click_player.load_slot(1)
        assert click_player.engine.pc == saved_pc
        assert len(click_player.current_choices) == 2
        assert click_player.backlog == saved_backlog
        assert click_player.save_slot(10)
        assert click_player.read_slot(10)['slot'] == 10
        assert save_slot_image_path(click_player.scenario_id, 10).is_file()
        assert click_player.delete_slot(10)
        assert click_player.read_slot(10) is None
        assert not save_slot_image_path(click_player.scenario_id, 10).exists()
        click_player.open_save_screen()
        root.update_idletasks(); root.update()
        assert click_player._save_window is not None and click_player._save_window.winfo_exists()
        assert click_player._save_preview_label is not None
        assert click_player._save_preview_label.winfo_exists()
        if save_slot_image_path(click_player.scenario_id, 1).is_file():
            assert click_player._save_preview_label.cget('image'), 'selecting a slot with a PNG should display its thumbnail'
            assert click_player._save_preview_photo is not None
        else:
            assert '画面画像' in click_player._save_preview_label.cget('text')
        trees = [w for w in click_player._save_window.winfo_children() if isinstance(w, tk.Frame)]
        assert trees or click_player._save_window.winfo_children()
        click_player._save_window.destroy(); click_player._save_window = None
        click_player.open_backlog()
        root.update_idletasks(); root.update()
        assert click_player._backlog_window is not None and click_player._backlog_window.winfo_exists()
        click_player._backlog_window.destroy(); click_player._backlog_window = None
        click_player.choose(1)
        assert click_player._typing_text == 'Bルートに入りました'
        assert any(x['kind'] == 'choice' and x['text'] == 'Bルートへ進む' for x in click_player.backlog)

click_player.close(); root.destroy()
print('GUI smoke passed: click-to-advance, right-click menu, 10-slot save/load, fresh-player resume, backlog and choice state')
