import json, os, sys, tempfile, unittest
from unittest.mock import patch
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import ScenarioEngine, project_to_nse, nse_to_project, validate_script, parse_script, DEFAULT_DISPLAY_SETTINGS, normalize_display_settings, save_display_settings, load_display_settings

class DesktopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT/'examples/testplay_5min.nproj').read_text(encoding='utf-8'))
        cls.source = project_to_nse(cls.project)

    def test_project_conversion_creates_labels(self):
        labels = [c['args'][0] for c in parse_script(self.source) if c['op']=='label']
        self.assertEqual(len(labels), 12)
        self.assertIn('true_end', labels)
        self.assertIn('quiet_end', labels)

    def test_no_syntax_errors(self):
        errors = [x for x in validate_script(self.source) if x[0]=='エラー']
        self.assertEqual(errors, [])

    def test_four_route_combinations(self):
        # First choice: talk(0) / silent(1); second: open letter(0) / walk to park(1)
        expected = {
          (0,0): 'true_end', (0,1): 'true_end',
          (1,0): 'quiet_end', (1,1): 'quiet_end'
        }
        for choices, ending in expected.items():
            engine = ScenarioEngine(self.source)
            event = engine.advance()
            while event['type'] != 'choices': event = engine.advance()
            event = engine.advance(choices[0])
            while event['type'] != 'choices': event = engine.advance()
            event = engine.advance(choices[1])
            while event['type'] != 'end':
                event = engine.advance()
                if event['type'] == 'choices':
                    event = engine.advance(0)
            self.assertIn(ending, engine.ending_flags, f'choice sequence {choices}')


    def test_project_roundtrip_preserves_scene_labels_and_branches(self):
        roundtrip = nse_to_project(self.source, "roundtrip")
        labels = [s["label"] for s in roundtrip["scenes"]]
        self.assertEqual(len(labels), 12)
        self.assertIn("talk_route", labels)
        start_scene = next(s for s in roundtrip["scenes"] if s["label"] == "start")
        self.assertEqual(start_scene["title"], "雨の終電ホーム")
        flat = [b for s in roundtrip["scenes"] for b in s["blocks"]]
        self.assertTrue(any(b["type"] == "select" for b in flat))
        self.assertTrue(any(b["type"] == "if" and b["target"] == "letter_talk" for b in flat))
        self.assertEqual(len(roundtrip["assets"]), 9)  # only assets referenced by script blocks are reconstructed
        chara = next(a for a in roundtrip["assets"] if a["type"] == "chara")
        self.assertEqual(len(chara["expressions"]), 2)

    def test_unknown_instruction_warning(self):
        issues=validate_script('*start\nfuture_cmd x\nend\n')
        self.assertTrue(any(x[0]=='警告' for x in issues))

    def test_missing_jump_error(self):
        issues=validate_script('*start\njump nowhere\n')
        self.assertTrue(any(x[0]=='エラー' and 'nowhere' in x[2] for x in issues))

    def test_zero_wait_preserved(self):
        eng=ScenarioEngine('*start\nwait 0\nend\n')
        self.assertEqual(eng.advance(), {'type':'wait','ms':0})


    def test_display_settings_accept_custom_appearance(self):
        settings = normalize_display_settings({
            "layout": "fullscreen", "font_family": "Yu Gothic UI", "font_size": 28,
            "font_weight": "bold", "text_color": "#ffddaa", "text_align": "center",
            "name_color": "#aaddff", "panel_color": "#112233", "panel_border": "#445566",
            "panel_pattern": "", "panel_position": "middle", "panel_height": 42,
            "side_margin": 5, "typewriter": True, "type_speed": 75
        })
        self.assertEqual(settings["layout"], "fullscreen")
        self.assertEqual(settings["font_family"], "Yu Gothic UI")
        self.assertEqual(settings["font_size"], 28)
        self.assertEqual(settings["text_align"], "center")
        self.assertTrue(settings["typewriter"])
        self.assertEqual(settings["type_speed"], 75)

    def test_display_settings_reject_invalid_values_and_clamp_ranges(self):
        settings = normalize_display_settings({
            "layout": "unknown", "font_size": 999, "type_speed": 1,
            "text_color": "not-a-color", "panel_position": "elsewhere"
        })
        self.assertEqual(settings["layout"], DEFAULT_DISPLAY_SETTINGS["layout"])
        self.assertEqual(settings["font_size"], 48)
        self.assertEqual(settings["type_speed"], 10)
        self.assertEqual(settings["text_color"], DEFAULT_DISPLAY_SETTINGS["text_color"])
        self.assertEqual(settings["panel_position"], DEFAULT_DISPLAY_SETTINGS["panel_position"])


    def test_display_settings_persist_between_launches(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": temp_dir, "APPDATA": temp_dir}):
                custom = normalize_display_settings({"font_size": 24, "text_color": "#aabbcc", "typewriter": True})
                save_display_settings(custom)
                loaded = load_display_settings()
                self.assertEqual(loaded["font_size"], 24)
                self.assertEqual(loaded["text_color"], "#aabbcc")
                self.assertTrue(loaded["typewriter"])

    def test_quote_error(self):
        issues=validate_script('*start\ntext "broken\nend')
        self.assertTrue(any(x[0]=='エラー' for x in issues))

if __name__ == '__main__': unittest.main()
