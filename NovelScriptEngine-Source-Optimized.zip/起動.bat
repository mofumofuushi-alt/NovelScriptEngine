@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0NovelScriptEngine.exe" (
  start "" "%~dp0NovelScriptEngine.exe"
  exit /b 0
)
echo NovelScriptEngine.exe が見つかりません。
echo GitHub Actions で Windows 用 EXE を作成し、このフォルダに配置してください。
echo 詳細は WINDOWS_BUILD_GUIDE.md を参照してください。
pause
exit /b 1
